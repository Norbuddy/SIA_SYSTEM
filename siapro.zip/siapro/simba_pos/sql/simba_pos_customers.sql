-- Simba POS customer accounts and table setup
CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL UNIQUE,
  `username` varchar(100) NOT NULL UNIQUE,
  `phone` varchar(30) DEFAULT '',
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` (`name`, `email`, `username`, `phone`, `password`, `created_at`) VALUES
('Jane Doe', 'jane@example.com', 'janedoe', '09123456789', '$2y$10$2ulROFwd4RJzFBuPBWctxuIVHPsFRDMp6pFHGOXICAeIESUjioYxK', '2026-07-03 12:00:00'),
('John Smith', 'john@example.com', 'johnsmith', '09998887766', '$2y$10$DNau6yaisFQyNoEseTobReBObZ7C8JPiOwulOJaeCb1qS0uqkcB2.', '2026-07-03 12:00:00');
