-- Orders and order_items migration
-- Run these statements in phpMyAdmin or via your MySQL client if the tables/columns are missing.

-- Create orders table if missing
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT(10) UNSIGNED NOT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `delivery_method` ENUM('Shipping','Pickup') NOT NULL DEFAULT 'Pickup',
  `shipping_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `full_name` VARCHAR(150) DEFAULT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `street_address` VARCHAR(255) DEFAULT NULL,
  `barangay` VARCHAR(255) DEFAULT NULL,
  `city` VARCHAR(150) DEFAULT NULL,
  `province` VARCHAR(150) DEFAULT NULL,
  `zip_code` VARCHAR(20) DEFAULT NULL,
  `status` ENUM('Pending','Processing','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  `order_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create order_items table if missing
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT(10) UNSIGNED NOT NULL,
  `product_id` INT(10) UNSIGNED NOT NULL,
  `quantity` INT(10) UNSIGNED NOT NULL,
  `unit_price` DECIMAL(10,2) NOT NULL,
  `total_price` DECIMAL(10,2) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX (`order_id`),
  INDEX (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional: Add missing columns to existing orders table
ALTER TABLE `orders`
  ADD COLUMN IF NOT EXISTS `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `delivery_method` ENUM('Shipping','Pickup') NOT NULL DEFAULT 'Pickup',
  ADD COLUMN IF NOT EXISTS `shipping_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `grand_total` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `full_name` VARCHAR(150) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `phone` VARCHAR(30) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `street_address` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `barangay` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `city` VARCHAR(150) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `province` VARCHAR(150) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `zip_code` VARCHAR(20) DEFAULT NULL;

-- Note: Some MySQL versions do not support ADD COLUMN IF NOT EXISTS in a single ALTER statement; you may need to run individual ALTER TABLE ADD COLUMN statements.
