/**
 * Simba Cafe POS — cashier.js
 * Full front-end logic for POS, Inventory, Transactions, and Profile panels.
 * Relies on globals injected by cashier_dashboard.php:
 *   PRODUCTS, CATEGORIES, TAX_RATE, CURRENCY, CASHIER, CAFE_NAME, CAFE_ADDR, CAFE_PHONE, IS_ADMIN
 */

'use strict';

/* ═══════════════════════════════════════════════════════════════
   GLOBAL STATE
═══════════════════════════════════════════════════════════════ */
let currentOrder   = [];   // [{ id, name, icon, price, qty }]
let discountPct    = 0;
let payMethod      = 'cash';
let histFilter     = 'all';
let histOffset     = 0;
let histAll        = [];   // cached rows from last fetch
let activePanel    = 'pos';

/* ═══════════════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
    showPanel('pos');
    renderOrder();
});

/* ═══════════════════════════════════════════════════════════════
   PANEL SWITCHING
═══════════════════════════════════════════════════════════════ */
function showPanel(panel) {
    document.querySelectorAll('.pos-panel').forEach(p => p.style.display = 'none');
    const el = document.getElementById('panel-' + panel);
    if (el) el.style.display = 'block';
    activePanel = panel;

    // Highlight active nav button
    document.querySelectorAll('.t-btn').forEach(b => b.classList.remove('active'));
    const nb = document.getElementById('nav-' + (panel === 'history' ? 'history' : panel));
    if (nb) nb.classList.add('active');

    if (panel === 'history') loadHistory(false);
    if (panel === 'orders') loadOrders();
}

/* ═══════════════════════════════════════════════════════════════
   API BRIDGE
═══════════════════════════════════════════════════════════════ */
async function apiCall(action, data = {}, method = 'POST') {
    const formData = new FormData();
    formData.append('action', action);
    for (const key in data) {
        formData.append(key, data[key] === null ? '' : data[key]);
    }
    try {
        const endpoint = (typeof API_URL !== 'undefined') ? API_URL : 'api.php';
        const res = await fetch(endpoint, { method, body: formData, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const text = await res.text();
        try {
            const json = JSON.parse(text);
            return json;
        } catch (e) {
            console.error('Non-JSON response from API:', text);
            return { success: false, message: 'Server error: ' + (text ? text.substring(0, 300) : 'Empty response') };
        }
    } catch (e) {
        console.error('API error:', e);
        return { success: false, message: 'Network or server error.' };
    }
}

async function apiGet(action, params = {}) {
    const qs = new URLSearchParams({ action, ...params }).toString();
    try {
        const endpoint = (typeof API_URL !== 'undefined') ? API_URL : 'api.php';
        const res = await fetch(endpoint + '?' + qs, { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const text = await res.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error('Non-JSON response from API (GET):', text);
            return { success: false, message: 'Server error: ' + (text ? text.substring(0, 300) : 'Empty response') };
        }
    } catch (e) {
        console.error('API GET error:', e);
        return { success: false, message: 'Network or server error.' };
    }
}

async function loadOrders() {
        const tbody = document.getElementById('order-tbody');
        if (!tbody) return;
        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">Loading…</td></tr>';
        const res = await apiGet('get_orders');
        if (!res.success) {
                tbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">${res.message}</td></tr>`;
                return;
        }
        const rows = res.data || [];
        if (rows.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted">No orders found.</td></tr>';
                return;
        }
        tbody.innerHTML = rows.map(order => {
                return `
                    <tr data-search="${order.id} ${order.customer_name.toLowerCase()} ${order.customer_phone || order.customer_email || ''} ${order.item_summary?.toLowerCase() || ''}">
                        <td>#${order.id}</td>
                        <td>${new Date(order.order_date).toLocaleString()}</td>
                        <td>${order.customer_name}</td>
                        <td>${order.customer_phone || order.customer_email || '—'}</td>
                        <td>${order.item_summary || '—'}</td>
                        <td style="text-align:center">${order.total_quantity || 0}</td>
                        <td>${order.delivery_method}</td>
                        <td>${CURRENCY}${parseFloat(order.grand_total).toFixed(2)}</td>
                        <td>${order.status}</td>
                        <td><button class="btn-ed be" onclick="viewOrder(${order.id})">View</button></td>
                    </tr>`;
        }).join('');
}

function filterOrderTable() {
        const query = (document.getElementById('order-search')?.value || '').toLowerCase().trim();
        document.querySelectorAll('#order-tbody tr').forEach(row => {
                const text = row.dataset.search || '';
                row.style.display = !query || text.includes(query) ? '' : 'none';
        });
}

async function viewOrder(id) {
        const res = await apiGet('get_order', { id });
        if (!res.success) { toast(res.message, 'err'); return; }
        const order = res.data;
        const existing = document.getElementById('mo-order-detail');
        if (existing) existing.remove();
        const items = order.items.map(item => `
            <div class="rcp-row">
                <span>${item.quantity} × ${item.product_name}</span>
                <strong>${CURRENCY}${parseFloat(item.total_price).toFixed(2)}</strong>
            </div>`).join('');
        const details = `
            <div class="rcp-row"><strong>Order #</strong><span>${order.id}</span></div>
            <div class="rcp-row"><strong>Customer</strong><span>${sanitizeHtml(order.customer_name)}</span></div>
            <div class="rcp-row"><strong>Contact</strong><span>${sanitizeHtml(order.customer_phone || order.customer_email || '')}</span></div>
            <div class="rcp-row"><strong>Method</strong><span>${sanitizeHtml(order.delivery_method)}</span></div>
            <div class="rcp-row"><strong>Status</strong>
                <select id="order-status-${order.id}">
                    <option value="Pending"${order.status === 'Pending' ? ' selected' : ''}>Pending</option>
                    <option value="Processing"${order.status === 'Processing' ? ' selected' : ''}>Processing</option>
                    <option value="To Ship"${order.status === 'To Ship' ? ' selected' : ''}>To Ship</option>
                    <option value="Received"${order.status === 'Received' ? ' selected' : ''}>Received</option>
                    <option value="Completed"${order.status === 'Completed' ? ' selected' : ''}>Completed</option>
                    <option value="Cancelled"${order.status === 'Cancelled' ? ' selected' : ''}>Cancelled</option>
                </select>
            </div>
            <div class="rcp-row"><strong>Subtotal</strong><span>${CURRENCY}${parseFloat(order.subtotal).toFixed(2)}</span></div>
            <div class="rcp-row"><strong>Shipping</strong><span>${CURRENCY}${parseFloat(order.shipping_fee).toFixed(2)}</span></div>
            <div class="rcp-row"><strong>Total</strong><span>${CURRENCY}${parseFloat(order.grand_total).toFixed(2)}</span></div>
            ${order.delivery_method === 'Shipping' ? `
                <div class="rcp-row"><strong>Ship To</strong><span>${sanitizeHtml(order.full_name)}</span></div>
                <div class="rcp-row"><span>${sanitizeHtml(order.street_address)}, ${sanitizeHtml(order.barangay)}</span></div>
                <div class="rcp-row"><span>${sanitizeHtml(order.city)}, ${sanitizeHtml(order.province)} ${sanitizeHtml(order.zip_code)}</span></div>
                <div class="rcp-row"><strong>Phone</strong><span>${sanitizeHtml(order.phone)}</span></div>
            ` : ''}
            <div class="rcp-row"><strong>Items</strong></div>
            ${items}
            <div class="rcp-row"><button class="btn-p" onclick="updateOrderStatus(${order.id})">Save Status</button></div>
        `;
        const modal = document.createElement('div');
        modal.className = 'mo on';
        modal.id = 'mo-order-detail';
        modal.innerHTML = `
            <div class="mo-card">
                <div class="mo-header"><h3>Order #${order.id}</h3><button class="btn-clr" onclick="closeMo('mo-order-detail')">×</button></div>
                <div class="mo-body">${details}</div>
            </div>`;
        document.body.appendChild(modal);
}

async function updateOrderStatus(id) {
        const select = document.getElementById(`order-status-${id}`);
        if (!select) return;
        const status = select.value;
        const res = await apiCall('update_order', { id, status });
        if (res.success) {
                toast(res.message);
                closeMo('mo-order-detail');
                loadOrders();
        } else {
                toast(res.message, 'err');
        }
}

function sanitizeHtml(value) {
        const div = document.createElement('div');
        div.textContent = value;
        return div.innerHTML;
}

/* ═══════════════════════════════════════════════════════════════
   TOAST NOTIFICATIONS
═══════════════════════════════════════════════════════════════ */
function toast(msg, type = 'ok') {
    const wrap = document.getElementById('toast-wrap');
    if (!wrap) return;
    const t = document.createElement('div');
    t.className = `tst ${type}`;
    t.innerHTML = `<i class="bi bi-${type === 'ok' ? 'check-circle-fill' : 'exclamation-circle-fill'}"></i> ${msg}`;
    wrap.appendChild(t);
    setTimeout(() => t.remove(), 3200);
}

/* ═══════════════════════════════════════════════════════════════
   MODAL HELPERS
═══════════════════════════════════════════════════════════════ */
function openMo(id) {
    const el = document.getElementById(id);
    if (el) { el.classList.add('on'); }
}

function closeMo(id) {
    const els = document.querySelectorAll(`#${CSS.escape(id)}`);
    els.forEach(el => {
        el.classList.remove('on');
        if (id === 'mo-order-detail') {
            el.remove();
        }
    });
}

// Close modals on backdrop click
document.addEventListener('click', e => {
    if (e.target.classList.contains('mo')) closeMo(e.target.id);
});

/* ═══════════════════════════════════════════════════════════════
   POS — PRODUCT GRID
═══════════════════════════════════════════════════════════════ */
let currentCat = 'all';

function setCategory(catId, el) {
    currentCat = catId;
    document.querySelectorAll('.cat-itm').forEach(c => c.classList.remove('on'));
    if (el) el.classList.add('on');
    filterPOS();
}

function filterPOS() {
    const q    = (document.getElementById('pos-q')?.value || '').toLowerCase().trim();
    const cards = document.querySelectorAll('#prod-grid .p-card');
    let visible = 0;
    cards.forEach(card => {
        const matchCat  = currentCat === 'all' || card.dataset.cat === String(currentCat);
        const matchName = !q || card.dataset.name.includes(q);
        const show = matchCat && matchName;
        card.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    const noEl = document.getElementById('no-prod');
    if (noEl) noEl.style.display = visible === 0 ? 'block' : 'none';
}

/* ═══════════════════════════════════════════════════════════════
   POS — ORDER MANAGEMENT
═══════════════════════════════════════════════════════════════ */
function addToOrder(productId) {
    const card = document.querySelector(`.p-card[data-id="${productId}"]`);
    if (!card) return;
    const stock = parseInt(card.dataset.stock, 10);
    if (stock === 0) { toast('This item is out of stock.', 'err'); return; }

    const existing = currentOrder.find(i => i.id === productId);
    const qtyInOrder = existing ? existing.qty : 0;

    if (qtyInOrder >= stock) {
        toast(`Only ${stock} in stock.`, 'err');
        return;
    }

    if (existing) {
        existing.qty++;
    } else {
        currentOrder.push({
            id:    productId,
            name:  card.querySelector('.p-name').textContent,
            icon:  card.querySelector('.p-emo').textContent,
            price: parseFloat(card.dataset.price),
            qty:   1,
        });
    }

    // Flash card
    card.classList.add('p-flash');
    setTimeout(() => card.classList.remove('p-flash'), 300);

    renderOrder();
}

function changeQty(productId, delta) {
    const item = currentOrder.find(i => i.id === productId);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
        currentOrder = currentOrder.filter(i => i.id !== productId);
    }
    renderOrder();
}

function removeItem(productId) {
    currentOrder = currentOrder.filter(i => i.id !== productId);
    renderOrder();
}

function clearOrder() {
    if (currentOrder.length === 0) return;
    currentOrder = [];
    discountPct = 0;
    const discEl = document.getElementById('disc');
    if (discEl) discEl.value = '';
    renderOrder();
}

function applyDiscount() {
    const val = parseFloat(document.getElementById('disc')?.value || 0);
    discountPct = isNaN(val) ? 0 : Math.min(100, Math.max(0, val));
    renderOrder();
}

function renderOrder() {
    const body   = document.getElementById('ord-body');
    const empty  = document.getElementById('ord-empty');
    const btnPay = document.getElementById('btn-pay');

    if (!body) return;

    if (currentOrder.length === 0) {
        body.innerHTML = '';
        if (empty) { empty.style.display = 'block'; body.appendChild(empty); }
        if (btnPay) btnPay.disabled = true;
        updateTotals(0);
        return;
    }

    if (empty) empty.style.display = 'none';

    let subtotal = 0;
    let html = '';
    currentOrder.forEach(item => {
        const lineTotal = item.price * item.qty;
        subtotal += lineTotal;
        html += `
        <div class="ord-row" data-id="${item.id}">
          <div class="ord-item">
            <span class="p-emo" style="font-size:1.1rem">${item.icon}</span>
            <span class="ord-item-name">${item.name}</span>
          </div>
          <div class="ord-qty">
            <button class="q-btn" onclick="changeQty(${item.id},-1)">−</button>
            <span class="q-val">${item.qty}</span>
            <button class="q-btn" onclick="changeQty(${item.id},1)">+</button>
          </div>
          <div class="ord-price">
            ${CURRENCY}${lineTotal.toFixed(2)}
            <button class="q-btn" onclick="removeItem(${item.id})" title="Remove" style="font-size:.6rem;margin-left:2px">✕</button>
          </div>
        </div>`;
    });

    body.innerHTML = html;
    if (btnPay) btnPay.disabled = false;
    updateTotals(subtotal);
}

function updateTotals(subtotal) {
    const taxAmt  = subtotal * TAX_RATE;
    const discAmt = subtotal * (discountPct / 100);
    const total   = subtotal + taxAmt - discAmt;

    setText('lbl-sub',  `${CURRENCY}${subtotal.toFixed(2)}`);
    setText('lbl-tax',  `${CURRENCY}${taxAmt.toFixed(2)}`);
    setText('lbl-disc', `-${CURRENCY}${discAmt.toFixed(2)}`);
    setText('lbl-tot',  `${CURRENCY}${total.toFixed(2)}`);
}

function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
}

/* ═══════════════════════════════════════════════════════════════
   POS — PAYMENT MODAL
═══════════════════════════════════════════════════════════════ */
function openPayModal() {
    if (currentOrder.length === 0) return;

    const subtotal = currentOrder.reduce((s, i) => s + i.price * i.qty, 0);
    const taxAmt   = subtotal * TAX_RATE;
    const discAmt  = subtotal * (discountPct / 100);
    const total    = subtotal + taxAmt - discAmt;

    setText('pay-due', `${CURRENCY}${total.toFixed(2)}`);
    setText('chng-val', `${CURRENCY}0.00`);

    const cashIn = document.getElementById('cash-in');
    if (cashIn) cashIn.value = '';

    // Quick-cash buttons
    const qc = document.getElementById('quick-cash');
    if (qc) {
        const amounts = [Math.ceil(total / 5) * 5, Math.ceil(total / 10) * 10, Math.ceil(total / 50) * 50, Math.ceil(total / 100) * 100]
            .filter((v, i, a) => a.indexOf(v) === i && v >= total)
            .slice(0, 4);
        qc.innerHTML = amounts.map(a =>
            `<button class="btn-ed be" style="flex:1;padding:6px;font-size:.77rem" onclick="setCash(${a})">${CURRENCY}${a.toFixed(0)}</button>`
        ).join('');
    }

    setPayMethod('cash', document.querySelector('.pm-m'));
    openMo('mo-pay');
}

function setPayMethod(method, el) {
    payMethod = method;
    document.querySelectorAll('.pm-m').forEach(m => m.classList.remove('on'));
    if (el) el.classList.add('on');
    document.getElementById('sec-cash').style.display  = method === 'cash'  ? '' : 'none';
    document.getElementById('sec-card').style.display  = method === 'card'  ? '' : 'none';
    document.getElementById('sec-gcash').style.display = method === 'gcash' ? '' : 'none';
}

function setCash(amount) {
    const el = document.getElementById('cash-in');
    if (el) { el.value = amount; calcChange(); }
}

function calcChange() {
    const dueText = document.getElementById('pay-due')?.textContent || '0';
    const due  = parseFloat(dueText.replace(/[^0-9.]/g, '')) || 0;
    const recv = parseFloat(document.getElementById('cash-in')?.value || 0);
    const change = Math.max(0, recv - due);
    setText('chng-val', `${CURRENCY}${change.toFixed(2)}`);
}

async function confirmPayment() {
    const subtotal = currentOrder.reduce((s, i) => s + i.price * i.qty, 0);
    const taxAmt   = subtotal * TAX_RATE;
    const discAmt  = subtotal * (discountPct / 100);
    const total    = subtotal + taxAmt - discAmt;

    let cashRecv = 0, cardRef = '', gcashRef = '';

    if (payMethod === 'cash') {
        cashRecv = parseFloat(document.getElementById('cash-in')?.value || 0);
        if (cashRecv < total) { toast('Cash received is less than the total.', 'err'); return; }
    } else if (payMethod === 'card') {
        cardRef = document.getElementById('card-ref')?.value || '';
    } else if (payMethod === 'gcash') {
        gcashRef = document.getElementById('gcash-ref')?.value || '';
    }

    const items = currentOrder.map(i => ({ id: i.id, qty: i.qty }));

    const btn = document.querySelector('#mo-pay .btn-pay');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="bi bi-hourglass-split"></i> Processing…'; }

    const res = await apiCall('checkout', {
        items:          JSON.stringify(items),
        discount_pct:   discountPct,
        payment_method: payMethod,
        cash_received:  cashRecv,
        card_ref:       cardRef,
        gcash_ref:      gcashRef,
    });

    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="bi bi-check-circle-fill"></i> Confirm Payment'; }

    if (!res.success) { toast(res.message, 'err'); return; }

    closeMo('mo-pay');
    showReceipt(res);
    // Update product card stock counts in the DOM
    currentOrder.forEach(item => {
        const card = document.querySelector(`.p-card[data-id="${item.id}"]`);
        if (card) {
            let stock = parseInt(card.dataset.stock, 10) - item.qty;
            stock = Math.max(0, stock);
            card.dataset.stock = stock;
            // Update status badge
            let statusEl = card.querySelector('.p-status');
            if (stock === 0) {
                card.classList.add('p-out');
                if (!statusEl) { statusEl = document.createElement('div'); statusEl.className = 'p-status'; card.appendChild(statusEl); }
                statusEl.className = 'p-status out'; statusEl.textContent = 'OUT OF STOCK';
            } else if (stock < 10) {
                card.classList.remove('p-out');
                if (!statusEl) { statusEl = document.createElement('div'); statusEl.className = 'p-status'; card.appendChild(statusEl); }
                statusEl.className = 'p-status low'; statusEl.textContent = `Low: ${stock} left`;
            } else {
                card.classList.remove('p-out');
                if (statusEl) statusEl.remove();
            }
        }
    });
}

/* ═══════════════════════════════════════════════════════════════
   POS — RECEIPT
═══════════════════════════════════════════════════════════════ */
function showReceipt(txn) {
    const body = document.getElementById('rcp-body');
    if (!body) return;
    body.innerHTML = buildReceiptHTML(txn);
    openMo('mo-rcp');
}

function buildReceiptHTML(txn) {
    const date = txn.created_at
        ? new Date(txn.created_at).toLocaleString()
        : new Date().toLocaleString();

    let itemsHTML = (txn.items || []).map(i =>
        `<div class="rcp-row">
           <span>${i.product_icon || ''} ${i.product_name} × ${i.quantity}</span>
           <span>${CURRENCY}${parseFloat(i.line_total).toFixed(2)}</span>
         </div>`
    ).join('');

    const payLabel = { cash: 'Cash', card: 'Card', gcash: 'GCash' }[txn.payment_method] || txn.payment_method;
    const changeRow = txn.payment_method === 'cash'
        ? `<div class="rcp-row"><span>Cash Received</span><span>${CURRENCY}${parseFloat(txn.cash_received||0).toFixed(2)}</span></div>
           <div class="rcp-row"><span>Change</span><span>${CURRENCY}${parseFloat(txn.change_amount||0).toFixed(2)}</span></div>` : '';
    const refRow = txn.payment_method === 'card' && txn.card_ref
        ? `<div class="rcp-row"><span>Card Ref</span><span>${txn.card_ref}</span></div>` : '';
    const gcashRow = txn.payment_method === 'gcash' && txn.gcash_ref
        ? `<div class="rcp-row"><span>GCash Ref</span><span>${txn.gcash_ref}</span></div>` : '';

    return `
    <div style="text-align:center;margin-bottom:12px">
      <div style="font-size:1.05rem;font-weight:800">${CAFE_NAME}</div>
      ${CAFE_ADDR ? `<div style="font-size:.72rem;color:#888">${CAFE_ADDR}</div>` : ''}
      ${CAFE_PHONE ? `<div style="font-size:.72rem;color:#888">${CAFE_PHONE}</div>` : ''}
      <div style="font-size:.7rem;color:#aaa;margin-top:4px">${date}</div>
    </div>
    <div class="rcp-row" style="margin-bottom:6px;padding-bottom:6px;border-bottom:1px dashed #ddd">
      <span style="font-size:.7rem;color:#888">TXN</span>
      <span style="font-size:.8rem;font-weight:700">${txn.txn_code || '—'}</span>
    </div>
    <div class="rcp-row" style="margin-bottom:4px;padding-bottom:4px;border-bottom:1px dashed #ddd">
      <span style="font-size:.7rem;color:#888">Cashier</span>
      <span style="font-size:.78rem">${txn.cashier || CASHIER}</span>
    </div>
    <div style="margin:10px 0 6px;font-size:.7rem;color:#999;text-transform:uppercase;letter-spacing:.06em">Items</div>
    ${itemsHTML}
    <div style="border-top:1px dashed #ddd;margin:10px 0 6px"></div>
    <div class="rcp-row"><span>Subtotal</span><span>${CURRENCY}${parseFloat(txn.subtotal||0).toFixed(2)}</span></div>
    <div class="rcp-row"><span>Tax (${Math.round(TAX_RATE*100)}%)</span><span>${CURRENCY}${parseFloat(txn.tax_amount||0).toFixed(2)}</span></div>
    ${parseFloat(txn.discount_pct||0) > 0 ? `<div class="rcp-row"><span>Discount (${txn.discount_pct}%)</span><span>-${CURRENCY}${parseFloat(txn.discount_amt||txn.discount_amount||0).toFixed(2)}</span></div>` : ''}
    <div class="rcp-row" style="font-weight:800;font-size:1rem;margin-top:6px">
      <span>TOTAL</span><span>${CURRENCY}${parseFloat(txn.total_amount||0).toFixed(2)}</span>
    </div>
    <div style="border-top:1px dashed #ddd;margin:10px 0 6px"></div>
    <div class="rcp-row"><span>Payment</span><span>${payLabel}</span></div>
    ${changeRow}${refRow}${gcashRow}
    <div style="text-align:center;margin-top:14px;font-size:.72rem;color:#aaa">Thank you for dining at ${CAFE_NAME}!</div>`;
}

function newOrder() {
    currentOrder = [];
    discountPct = 0;
    const discEl = document.getElementById('disc');
    if (discEl) discEl.value = '';
    renderOrder();
    showPanel('pos');
}

function printReceipt() {
    const body = document.getElementById('rcp-body');
    if (!body) return;
    const w = window.open('', '_blank', 'width=380,height=600');
    w.document.write(`<!DOCTYPE html><html><head><title>Receipt</title>
    <style>
      body{font-family:monospace;font-size:12px;padding:16px;max-width:320px;margin:0 auto}
      .rcp-row{display:flex;justify-content:space-between;margin:3px 0}
    </style></head><body>${body.innerHTML}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 400);
}

/* ═══════════════════════════════════════════════════════════════
   TRANSACTION HISTORY
═══════════════════════════════════════════════════════════════ */
async function loadHistory(append = false) {
    if (!append) {
        histOffset = 0;
        histAll = [];
        const tbody = document.getElementById('hist-tbody');
        if (tbody) tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">Loading…</td></tr>';
    }

    const filter = histFilter;
    const res = await apiGet('get_txn_history', { limit: 50, offset: histOffset });

    if (!res.success) { toast(res.message, 'err'); return; }

    let rows = res.data || [];

    // Client-side date filter
    const now = new Date();
    rows = rows.filter(t => {
        if (filter === 'all') return true;
        const d = new Date(t.created_at);
        const diff = (now - d) / 86400000;
        if (filter === 'today')  return diff < 1 && d.getDate() === now.getDate();
        if (filter === 'week')   return diff < 7;
        if (filter === 'month')  return diff < 30;
        return true;
    });

    histAll = append ? [...histAll, ...rows] : rows;
    histOffset += 50;

    renderHistTable(histAll);
    updateHistSummary(histAll);

    const moreBtn = document.getElementById('hist-load-more');
    if (moreBtn) moreBtn.style.display = (res.data || []).length === 50 ? 'block' : 'none';
}

function renderHistTable(rows) {
    const tbody = document.getElementById('hist-tbody');
    if (!tbody) return;
    if (rows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-muted">No transactions found.</td></tr>';
        return;
    }
    const payIcons = { cash: 'bi-cash-stack', card: 'bi-credit-card-fill', gcash: 'bi-phone-fill' };
    tbody.innerHTML = rows.map(t => `
    <tr data-txn="${t.txn_code?.toLowerCase() || ''}">
      <td><code style="font-size:.78rem;font-weight:700">${t.txn_code}</code></td>
      <td style="font-size:.78rem;color:#666">${formatDate(t.created_at)}</td>
      <td style="font-size:.8rem">${t.cashier_name || '—'}</td>
      <td style="text-align:center">${t.item_count || 0}</td>
      <td>
        <span class="bdg" style="background:rgba(232,119,34,.12);color:var(--orange)">
          <i class="bi ${payIcons[t.payment_method] || 'bi-cash'}"></i>
          ${t.payment_method}
        </span>
      </td>
      <td style="font-weight:700;color:var(--orange)">${CURRENCY}${parseFloat(t.total_amount).toFixed(2)}</td>
      <td>
        <button class="btn-ed be" onclick="viewTxn(${t.id})">
          <i class="bi bi-receipt"></i> View
        </button>
      </td>
    </tr>`).join('');
}

function updateHistSummary(rows) {
    const count   = rows.length;
    const revenue = rows.reduce((s, t) => s + parseFloat(t.total_amount || 0), 0);
    const cash    = rows.filter(t => t.payment_method === 'cash').reduce((s, t) => s + parseFloat(t.total_amount || 0), 0);
    const digital = rows.filter(t => t.payment_method !== 'cash').reduce((s, t) => s + parseFloat(t.total_amount || 0), 0);

    setText('hs-count',   count);
    setText('hs-revenue', `${CURRENCY}${revenue.toFixed(2)}`);
    setText('hs-cash',    `${CURRENCY}${cash.toFixed(2)}`);
    setText('hs-gcash',   `${CURRENCY}${digital.toFixed(2)}`);
}

function setHistFilter(filter, el) {
    histFilter = filter;
    document.querySelectorAll('.ftab').forEach(b => b.classList.remove('on'));
    if (el) el.classList.add('on');
    loadHistory(false);
}

function filterHistTable() {
    const q = (document.getElementById('hist-search')?.value || '').toLowerCase().trim();
    document.querySelectorAll('#hist-tbody tr').forEach(row => {
        row.style.display = !q || (row.dataset.txn || '').includes(q) ? '' : 'none';
    });
}

async function viewTxn(id) {
    const res = await apiGet('get_txn', { id });
    if (!res.success) { toast(res.message, 'err'); return; }
    const body = document.getElementById('txn-view-body');
    if (body) body.innerHTML = buildReceiptHTML(res.data);
    openMo('mo-txn-view');
}

function printTxnView() {
    const body = document.getElementById('txn-view-body');
    if (!body) return;
    const w = window.open('', '_blank', 'width=380,height=600');
    w.document.write(`<!DOCTYPE html><html><head><title>Receipt</title>
    <style>body{font-family:monospace;font-size:12px;padding:16px;max-width:320px;margin:0 auto}.rcp-row{display:flex;justify-content:space-between;margin:3px 0}</style>
    </head><body>${body.innerHTML}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 400);
}

function formatDate(str) {
    if (!str) return '—';
    const d = new Date(str);
    return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

/* ═══════════════════════════════════════════════════════════════
   INVENTORY
═══════════════════════════════════════════════════════════════ */
function filterInvTable() {
    const q = (document.getElementById('inv-search')?.value || '').toLowerCase().trim();
    document.querySelectorAll('#inv-tbody tr').forEach(row => {
        row.style.display = !q || (row.dataset.name || '').includes(q) ? '' : 'none';
    });
}

async function doUpdateStock(id) {
    const inp = document.getElementById('stk-' + id);
    if (!inp) return;
    const stock = parseInt(inp.value, 10);
    if (isNaN(stock) || stock < 0) { toast('Invalid stock value.', 'err'); return; }
    const res = await apiCall('update_stock', { id, stock });
    if (res.success) {
        toast(res.message);
        const card = document.querySelector(`.p-card[data-id="${id}"]`);
        if (card) {
            card.dataset.stock = stock;
            const statusEl = card.querySelector('.p-status');
            if (stock === 0) {
                card.classList.add('p-out');
                if (statusEl) {
                    statusEl.className = 'p-status out';
                    statusEl.textContent = 'OUT OF STOCK';
                }
            } else if (stock < 10) {
                card.classList.remove('p-out');
                if (statusEl) {
                    statusEl.className = 'p-status low';
                    statusEl.textContent = `Low: ${stock} left`;
                }
            } else {
                card.classList.remove('p-out');
                if (statusEl) statusEl.remove();
            }
        }
        const row = document.querySelector(`#inv-tbody tr[data-id='${id}']`);
        updateInventoryRow(id, stock, row);
    } else {
        toast(res.message, 'err');
    }
}

async function toggleProductAvailability(id, currentStatus) {
    const newStatus = currentStatus === 1 ? 0 : 1;
    const res = await apiCall('update_stock', { id, is_active: newStatus });
    if (!res.success) {
        toast(res.message, 'err');
        return;
    }
    toast(res.message);
    const row = document.querySelector(`#inv-tbody tr[data-id='${id}']`);
    if (row) {
        const statusCell = row.querySelector('td:nth-child(6) .bdg');
        if (statusCell) {
            statusCell.className = `bdg ${newStatus === 1 ? 'stk-ok' : 'stk-out'}`;
            statusCell.textContent = newStatus === 1 ? 'Available' : 'Unavailable';
        }
        const actionButton = row.querySelector('.availability-btn');
        if (actionButton) {
            actionButton.textContent = newStatus === 1 ? 'Mark Unavailable' : 'Mark Available';
            actionButton.setAttribute('onclick', `toggleProductAvailability(${id}, ${newStatus})`);
        }
    }
}

function updateInventoryRow(id, stock, row) {
    if (!row) return;
    const statusCell = row.querySelector('td:nth-child(7) .bdg');
    if (statusCell) {
        statusCell.className = `bdg ${stock === 0 ? 'stk-out' : stock < 10 ? 'stk-lo' : 'stk-ok'}`;
        statusCell.textContent = stock === 0 ? 'Out' : stock < 10 ? 'Low' : 'OK';
    }
}

/* Product Modal */
function openProdModal(prod = null) {
    document.getElementById('mo-prod-t').textContent = prod ? 'Edit Product' : 'Add Product';
    document.getElementById('p-id').value      = prod ? prod.id : '';
    document.getElementById('p-name').value    = prod ? prod.name : '';
    document.getElementById('p-icon').value    = prod ? prod.icon : '';
    document.getElementById('p-price').value   = prod ? prod.price : '';
    document.getElementById('p-stock').value   = prod ? prod.stock : '';
    document.getElementById('p-cat').value     = prod ? prod.category_id : (CATEGORIES[0]?.id || '');
    document.getElementById('p-active').value  = prod ? (prod.is_active ? '1' : '0') : '1';
    openMo('mo-prod');
}

async function saveProd(e) {
    e.preventDefault();
    const res = await apiCall('save_product', {
        id:          document.getElementById('p-id').value,
        name:        document.getElementById('p-name').value,
        icon:        document.getElementById('p-icon').value,
        price:       document.getElementById('p-price').value,
        stock:       document.getElementById('p-stock').value,
        category_id: document.getElementById('p-cat').value,
        is_active:   document.getElementById('p-active').value,
    });
    if (res.success) { toast(res.message); closeMo('mo-prod'); setTimeout(() => location.reload(), 800); }
    else toast(res.message, 'err');
}

async function deleteProd(id, name) {
    if (!confirm(`Delete "${name}"? If it has sales history it will be hidden instead.`)) return;
    const res = await apiCall('delete_product', { id });
    if (res.success) { toast(res.message); setTimeout(() => location.reload(), 800); }
    else toast(res.message, 'err');
}

/* Category Modal */
function openCatModal(cat = null) {
    document.getElementById('mo-cat-t').textContent = cat ? 'Edit Category' : 'Add Category';
    document.getElementById('cat-id').value    = cat ? cat.id : '';
    document.getElementById('cat-name').value  = cat ? cat.name : '';
    document.getElementById('cat-icon').value  = cat ? cat.icon : '';
    document.getElementById('cat-sort').value  = cat ? cat.sort_order : '0';
    openMo('mo-cat');
}

async function saveCat(e) {
    e.preventDefault();
    const res = await apiCall('save_category', {
        id:         document.getElementById('cat-id').value,
        name:       document.getElementById('cat-name').value,
        icon:       document.getElementById('cat-icon').value,
        sort_order: document.getElementById('cat-sort').value,
    });
    if (res.success) { toast(res.message); closeMo('mo-cat'); setTimeout(() => location.reload(), 800); }
    else toast(res.message, 'err');
}

async function deleteCat(id, name) {
    if (!confirm(`Delete category "${name}"? All products must be moved first.`)) return;
    const res = await apiCall('delete_category', { id });
    if (res.success) { toast(res.message); setTimeout(() => location.reload(), 800); }
    else toast(res.message, 'err');
}

/* ═══════════════════════════════════════════════════════════════
   PROFILE
═══════════════════════════════════════════════════════════════ */
async function saveProfile(e) {
    e.preventDefault();
    const pw      = document.getElementById('pf-pw')?.value || '';
    const confirm = document.getElementById('pf-confirm')?.value || '';
    if (pw && pw !== confirm) { toast('Passwords do not match.', 'err'); return; }

    const msgEl = document.getElementById('profile-msg');

    const res = await apiCall('update_profile', {
        name:     document.getElementById('pf-name')?.value || '',
        username: document.getElementById('pf-username')?.value || '',
        email:    document.getElementById('pf-email')?.value || '',
        phone:    document.getElementById('pf-phone')?.value || '',
        password: pw,
        confirm:  confirm,
    });

    if (res.success) {
        toast(res.message);
        // Update topbar display name
        setText('pf-display-name', res.name || '');
        if (msgEl) {
            msgEl.innerHTML = `<div class="alert-box ok"><i class="bi bi-check-circle-fill"></i> ${res.message}</div>`;
            msgEl.style.display = 'block';
            setTimeout(() => { msgEl.style.display = 'none'; }, 4000);
        }
    } else {
        toast(res.message, 'err');
        if (msgEl) {
            msgEl.innerHTML = `<div class="alert-box err"><i class="bi bi-exclamation-circle-fill"></i> ${res.message}</div>`;
            msgEl.style.display = 'block';
        }
    }
}

/* ═══════════════════════════════════════════════════════════════
   USER MANAGEMENT (Admin)
═══════════════════════════════════════════════════════════════ */
function openUserModal(user = null) {
    document.getElementById('mo-user-t').textContent = user ? 'Edit User' : 'Add User';
    document.getElementById('u-id').value       = user ? user.id : '';
    document.getElementById('u-name').value     = user ? user.name : '';
    document.getElementById('u-username').value = user ? user.username : '';
    document.getElementById('u-email').value    = user ? user.email : '';
    document.getElementById('u-phone').value    = user ? (user.phone || '') : '';
    document.getElementById('u-role').value     = user ? user.role : 'cashier';
    document.getElementById('u-status').value   = user ? user.status : 'active';
    document.getElementById('u-pw').value       = '';

    const hint = document.getElementById('u-pw-hint');
    if (hint) hint.textContent = user ? '(leave blank to keep current)' : '(required for new users)';

    openMo('mo-user');
}

async function saveUser(e) {
    e.preventDefault();
    const res = await apiCall('save_user', {
        id:       document.getElementById('u-id').value,
        name:     document.getElementById('u-name').value,
        username: document.getElementById('u-username').value,
        email:    document.getElementById('u-email').value,
        phone:    document.getElementById('u-phone').value,
        role:     document.getElementById('u-role').value,
        status:   document.getElementById('u-status').value,
        password: document.getElementById('u-pw').value,
    });
    if (res.success) { toast(res.message); closeMo('mo-user'); setTimeout(() => location.reload(), 800); }
    else toast(res.message, 'err');
}

async function toggleStatus(id, newStatus) {
    const res = await apiCall('toggle_status', { id, status: newStatus });
    if (res.success) { toast(res.message); setTimeout(() => location.reload(), 800); }
    else toast(res.message, 'err');
}

function resetPwModal(id, name) {
    document.getElementById('reset-uid').value   = id;
    document.getElementById('reset-pw-name').textContent = `Resetting password for: ${name}`;
    document.getElementById('reset-pw1').value   = '';
    document.getElementById('reset-pw2').value   = '';
    openMo('mo-reset-pw');
}

async function doResetPw() {
    const id  = document.getElementById('reset-uid')?.value;
    const pw1 = document.getElementById('reset-pw1')?.value || '';
    const pw2 = document.getElementById('reset-pw2')?.value || '';
    if (!id) return;
    if (pw1.length < 8) { toast('Password must be at least 8 characters.', 'err'); return; }
    if (pw1 !== pw2)    { toast('Passwords do not match.', 'err'); return; }
    const res = await apiCall('reset_password', { id, password: pw1 });
    if (res.success) { toast(res.message); closeMo('mo-reset-pw'); }
    else toast(res.message, 'err');
}

/* ═══════════════════════════════════════════════════════════════
   SETTINGS (Admin)
═══════════════════════════════════════════════════════════════ */
async function saveSettings(e) {
    e.preventDefault();
    const msgEl = document.getElementById('settings-msg');
    const res = await apiCall('save_settings', {
        cafe_name:    document.getElementById('s-name')?.value || '',
        cafe_address: document.getElementById('s-addr')?.value || '',
        cafe_phone:   document.getElementById('s-phone')?.value || '',
        tax_rate:     document.getElementById('s-tax')?.value || '10',
        currency:     document.getElementById('s-cur')?.value || '$',
        shipping_fee: document.getElementById('s-shipping')?.value || '50.00',
    });
    if (res.success) {
        toast(res.message);
        if (msgEl) {
            msgEl.innerHTML = `<div class="alert-box ok"><i class="bi bi-check-circle-fill"></i> ${res.message}</div>`;
            msgEl.style.display = 'block';
            setTimeout(() => { msgEl.style.display = 'none'; }, 4000);
        }
    } else {
        toast(res.message, 'err');
        if (msgEl) {
            msgEl.innerHTML = `<div class="alert-box err"><i class="bi bi-exclamation-circle-fill"></i> ${res.message}</div>`;
            msgEl.style.display = 'block';
        }
    }
}

/* ═══════════════════════════════════════════════════════════════
   UTILITY
═══════════════════════════════════════════════════════════════ */
/** Toggle password visibility in admin forms */
function tpwA(id, el) {
    const inp = document.getElementById(id);
    if (!inp) return;
    inp.type = inp.type === 'password' ? 'text' : 'password';
    el.className = 'bi bi-' + (inp.type === 'password' ? 'eye' : 'eye-slash');
}