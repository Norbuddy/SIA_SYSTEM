﻿<?php
// ============================================================
// index.php — Unified login and customer registration entry page
// ============================================================
require_once __DIR__ . '/config.php';

ensureAdminsTable();
ensureManagersTable();
ensureCustomersTable();

if (isLoggedIn()) {
    redirectToDashboard();
}

$errors = [];
$success = '';
$mode = $_GET['mode'] ?? 'login';

function normalizeCustomerUsername(string $email): string {
    $base = strtolower(preg_replace('/[^a-z0-9]/', '', strstr($email, '@', true) ?: $email));
    $username = $base ?: 'customer';
    $suffix = 0;
    $pdo = db();
    while (true) {
        $candidate = $username . ($suffix ? $suffix : '');
        $stmt = $pdo->prepare('SELECT id FROM customers WHERE username = ? LIMIT 1');
        $stmt->execute([$candidate]);
        if (!$stmt->fetch()) {
            return $candidate;
        }
        $suffix++;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'login') {
        $identifier = trim($_POST['identifier'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$identifier) {
            $errors[] = 'Email or username is required.';
        }
        if (!$password) {
            $errors[] = 'Password is required.';
        }

        if (empty($errors)) {
            try {
                $pdo = db();
                ensureAdminsTable();
                ensureManagersTable();
                ensureCustomersTable();

                $stmt = $pdo->prepare('SELECT * FROM customers WHERE email = ? OR username = ? LIMIT 1');
                $stmt->execute([$identifier, $identifier]);
                $customer = $stmt->fetch();
                if ($customer && password_verify($password, $customer['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['customer_id'] = (int)$customer['id'];
                    $_SESSION['customer_name'] = $customer['name'];
                    $_SESSION['customer_email'] = $customer['email'];
                    $_SESSION['customer_username'] = $customer['username'];
                    $_SESSION['user_role'] = 'customer';
                    redirectToDashboard();
                }

                $stmt = $pdo->prepare('SELECT * FROM admins WHERE (username = ? OR email = ?) AND status = ? LIMIT 1');
                $stmt->execute([$identifier, $identifier, 'active']);
                $admin = $stmt->fetch();
                if ($admin && password_verify($password, $admin['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = (int)$admin['id'];
                    $_SESSION['user_name'] = $admin['name'];
                    $_SESSION['user_email'] = $admin['email'];
                    $_SESSION['user_role'] = $admin['role'];
                    if ($_SESSION['user_role'] === 'admin') {
                        $_SESSION['admin_id'] = (int)$admin['id'];
                    } elseif ($_SESSION['user_role'] === 'cashier') {
                        $_SESSION['cashier_id'] = (int)$admin['id'];
                    }
                    redirectToDashboard();
                }

                $stmt = $pdo->prepare('SELECT * FROM managers WHERE (username = ? OR email = ?) AND status = ? LIMIT 1');
                $stmt->execute([$identifier, $identifier, 'active']);
                $manager = $stmt->fetch();
                if ($manager && password_verify($password, $manager['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = (int)$manager['id'];
                    $_SESSION['manager_id'] = (int)$manager['id'];
                    $_SESSION['user_name'] = $manager['name'];
                    $_SESSION['user_email'] = $manager['email'];
                    $_SESSION['user_role'] = 'manager';
                    redirectToDashboard();
                }

                $errors[] = 'Invalid credentials or inactive account.';
            } catch (Exception $e) {
                $errors[] = 'Unable to sign in. Please try again.';
            }
        }
    }

    if (($_POST['action'] ?? '') === 'register') {
        $mode = 'register';
        $name     = trim($_POST['reg_name'] ?? '');
        $username = strtolower(trim($_POST['reg_username'] ?? ''));
        $email    = strtolower(trim($_POST['reg_email'] ?? ''));
        $phone    = trim($_POST['reg_phone'] ?? '');
        $password = $_POST['reg_password'] ?? '';
        $confirm  = $_POST['reg_confirm'] ?? '';

       if (!$name || !$username || !$email || !$password) {
    $errors[] = 'All required fields are required.';
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid email address is required.';
}

if (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $username)) {
    $errors[] = 'Username must be 3–30 characters using only letters, numbers, and underscore.';
}

if ($phone && !preg_match('/^(\+63|0)9\d{9}$/', $phone)) {
    $errors[] = 'Please enter a valid Philippine mobile number.';
}

if (strlen($password) < 8) {
    $errors[] = 'Password must be at least 8 characters.';
}

if ($password !== $confirm) {
    $errors[] = 'Passwords do not match.';
}

if (empty($errors)) {
    try {

        $pdo = db();
        ensureCustomersTable();

        // Check duplicate username/email in all user tables
        $exists = false;

        foreach (['customers', 'admins', 'managers'] as $table) {

            $stmt = $pdo->prepare("SELECT id FROM {$table} WHERE email = ? OR username = ? LIMIT 1");
            $stmt->execute([$email, $username]);

            if ($stmt->fetch()) {
                $exists = true;
                break;
            }
        }

        if ($exists) {

            $errors[] = 'Username or email is already taken.';

        } else {

            $hash = password_hash($password, PASSWORD_BCRYPT);

            $stmt = $pdo->prepare("
                INSERT INTO customers
                (name, email, username, phone, password)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $name,
                $email,
                $username,
                $phone,
                $hash
            ]);

            $success = 'Registration complete. You may now sign in.';
            $mode = 'login';
        }

    } catch (Exception $e) {

        $errors[] = 'Unable to register. Please try again.';

    }
}
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $mode === 'register' ? 'Customer Registration' : 'Sign In' ?> — <?= sanitize(APP_NAME) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-page">
<div class="auth-bg">
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>

  <div class="auth-card" style="max-width:480px;">
    <div class="a-logo">
      <div class="a-ico"><i class="bi bi-cup-hot-fill"></i></div>
      <div>
        <h1><?= $mode === 'register' ? 'Create Customer Account' : 'Welcome Back' ?></h1>
        <span><?= $mode === 'register' ? 'Register as a customer' : 'Sign in to continue' ?></span>
      </div>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert-box err mb-3"><i class="bi bi-exclamation-circle-fill"></i> <?= sanitize(implode(' ', $errors)) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="alert-box ok mb-3"><i class="bi bi-check-circle-fill"></i> <?= sanitize($success) ?></div>
    <?php endif; ?>

    <?php if ($mode === 'register'): ?>
      <form method="POST" action="index.php?mode=register" autocomplete="off">

<input type="hidden" name="action" value="register">

<div class="fg">
    <label class="a-lbl">Full Name</label>

    <input
        class="a-inp"
        type="text"
        name="reg_name"
        value="<?= sanitize($_POST['reg_name'] ?? '') ?>"
        placeholder="Juan Dela Cruz"
        required>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">

    <div class="fg">
        <label class="a-lbl">Username</label>

        <input
            class="a-inp"
            type="text"
            name="reg_username"
            value="<?= sanitize($_POST['reg_username'] ?? '') ?>"
            placeholder="juandelacruz"
            pattern="[A-Za-z0-9_]{3,30}"
            required>
    </div>

    <div class="fg">
        <label class="a-lbl">Phone Number</label>

        <input
            class="a-inp"
            type="tel"
            name="reg_phone"
            value="<?= sanitize($_POST['reg_phone'] ?? '') ?>"
            placeholder="+63 917 123 4567"
            pattern="^(\+63|0)9\d{9}$"
            title="Example: 09171234567 or +639171234567">
    </div>

</div>

<div class="fg">
    <label class="a-lbl">Email Address</label>

    <input
        class="a-inp"
        type="email"
        name="reg_email"
        value="<?= sanitize($_POST['reg_email'] ?? '') ?>"
        placeholder="you@example.com"
        required>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">

    <div class="fg">
        <label class="a-lbl">Password</label>

        <div class="a-inp-wrap">
            <input
                class="a-inp"
                type="password"
                name="reg_password"
                id="r-pw1"
                placeholder="Minimum 8 characters"
                required>

            <i class="bi bi-eye eye"
               onclick="tpw('r-pw1',this)">
            </i>
        </div>
    </div>

    <div class="fg">
        <label class="a-lbl">Confirm Password</label>

        <div class="a-inp-wrap">
            <input
                class="a-inp"
                type="password"
                name="reg_confirm"
                id="r-pw2"
                placeholder="Repeat password"
                required>

            <i class="bi bi-eye eye"
               onclick="tpw('r-pw2',this)">
            </i>
        </div>
    </div>

</div>

<button type="submit" class="btn-a mt-2">
    <i class="bi bi-person-plus-fill"></i>
    Create Account
</button>

</form>
    <?php else: ?>
      <form method="POST" action="index.php" autocomplete="off">
        <input type="hidden" name="action" value="login">
        <div class="fg">
          <label class="a-lbl">Email or Username</label>
          <input class="a-inp" type="text" name="identifier" value="<?= sanitize($_POST['identifier'] ?? '') ?>" placeholder="Email or username" required>
        </div>
        <div class="fg">
          <label class="a-lbl">Password</label>
          <div class="a-inp-wrap">
            <input class="a-inp" type="password" name="password" id="l-pw" placeholder="••••••••" required>
            <div style="text-align:right; margin-bottom:18px;">
          </div>
            <i class="bi bi-eye eye" onclick="tpw('l-pw',this)"></i>
          </div>
          <a class="a-lnk" href="forgot_password.php">Forgot Password?</a>
        </div>
        <button type="submit" class="btn-a mt-2"><i class="bi bi-box-arrow-in-right"></i> Sign In</button>
      </form>
      <div class="text-center mt-3"><a class="a-lnk" href="index.php?mode=register">New customer? Create account</a></div>
    <?php endif; ?>
  </div>
</div>
<script>
function tpw(id, el) {
  const input = document.getElementById(id);
  if (!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
  el.className = 'eye bi bi-' + (input.type === 'password' ? 'eye' : 'eye-slash');
}
</script>
</body>
</html>
