<?php
require_once __DIR__ . '/customer_common.php';

if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset(
        $_SESSION['customer_id'],
        $_SESSION['customer_name'],
        $_SESSION['customer_email'],
        $_SESSION['customer_username'],
        $_SESSION['customer_cart']
    );
    header('Location: customer_login.php');
    exit;
}

requireCustomerLogin();
$customer = getCustomer();
$categories = fetchCategories();
$cart = getCustomerCart();
$cartItemCount = getCartItemCount($cart);

$search = trim((string)($_GET['search'] ?? ''));
$categoryId = (int)($_GET['category'] ?? 0);
$sort = in_array($_GET['sort'] ?? '', ['price_asc', 'price_desc', 'newest'], true)
    ? $_GET['sort']
    : 'newest';

$products = fetchProducts($search, $categoryId, $sort);
$cartProducts = fetchCartProducts($cart);
$cartTotals = ['quantity' => 0, 'price' => 0.0];
foreach ($cart as $productId => $quantity) {
    if (!isset($cartProducts[$productId])) {
        continue;
    }
    $cartTotals['quantity'] += $quantity;
    $cartTotals['price'] += $cartProducts[$productId]['price'] * $quantity;
}

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_to_cart') {
        $productId = max(0, (int)($_POST['product_id'] ?? 0));
        $quantity = max(1, (int)($_POST['quantity'] ?? 1));
        $stmt = db()->prepare('SELECT id, stock, is_active, name FROM products WHERE id = ? LIMIT 1');
        $stmt->execute([$productId]);
        $product = $stmt->fetch();

        if (!$product || (int)$product['is_active'] !== 1 || (int)$product['stock'] < 1) {
            $message = 'That product is not available to add.';
            $messageType = 'danger';
        } else {
            $currentQty = $cart[$productId] ?? 0;
            $newQty = min((int)$product['stock'], $currentQty + $quantity);
            $cart[$productId] = $newQty;
            setCustomerCart($cart);
            $message = 'Added to cart: ' . sanitize($product['name']);
        }
    }

    if ($action === 'update_cart') {
        $items = $_POST['items'] ?? [];
        foreach ($items as $productId => $quantity) {
            $productId = max(0, (int)$productId);
            $quantity = max(0, (int)$quantity);
            if ($quantity <= 0) {
                unset($cart[$productId]);
            } elseif (isset($cart[$productId])) {
                $stmt = db()->prepare('SELECT stock FROM products WHERE id = ? LIMIT 1');
                $stmt->execute([$productId]);
                $product = $stmt->fetch();
                $cart[$productId] = ($product && $product['stock'] >= $quantity)
                    ? $quantity
                    : min($quantity, (int)($product['stock'] ?? 0));
            }
        }
        setCustomerCart($cart);
        $message = 'Cart updated.';
    }

    if ($action === 'remove_item') {
        $productId = max(0, (int)($_POST['product_id'] ?? 0));
        unset($cart[$productId]);
        setCustomerCart($cart);
        $message = 'Item removed from cart.';
    }

    header('Location: customer_dashboard.php?search=' . urlencode($search) . '&category=' . $categoryId . '&sort=' . urlencode($sort) . '&message=' . urlencode($message) . '&type=' . urlencode($messageType));
    exit;
}

if (!empty($_GET['message'])) {
    $message = sanitize((string)$_GET['message']);
    $messageType = sanitize((string)($_GET['type'] ?? 'success'));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="shop.css">
</head>
<body class="shop-page">
<header class="shop-topbar">
    <div class="brand"><?= sanitize(APP_NAME) ?> Market</div>
    <div class="shop-nav-actions">
        <span class="customer-name">Hi, <?= sanitize($customer['name']) ?></span>
        <a href="customer_orders.php" class="btn btn-sm btn-outline-light">Orders</a>
        <a href="customer_checkout.php" class="btn btn-sm btn-outline-light">Checkout</a>
        <a href="customer_dashboard.php?action=logout" class="btn btn-sm btn-danger">Logout</a>
    </div>
</header>
<main class="shop-container">
    <div class="page-head">
        <p class="eyebrow">Customer Shop</p>
        <h1>Browse fresh products</h1>
        <p class="section-copy">Search, filter, sort, and add items to your cart before checkout.</p>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType === 'danger' ? 'danger' : 'success' ?>"><?= $message ?></div>
    <?php endif; ?>

    <div class="shop-grid">
        <section class="shop-panel">
            <div class="shop-actions">
                <form class="search-form" method="get" action="customer_dashboard.php">
                    <input type="search" name="search" placeholder="Search products" value="<?= sanitize($search) ?>">
                    <input type="hidden" name="category" value="<?= sanitize((string)$categoryId) ?>">
                    <input type="hidden" name="sort" value="<?= sanitize($sort) ?>">
                    <button type="submit"><i class="bi bi-search"></i></button>
                </form>
                <select onchange="this.form.submit()" form="filter-form" name="sort">
                    <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
                    <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price Low to High</option>
                    <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price High to Low</option>
                </select>
            </div>

            <form id="filter-form" method="get" action="customer_dashboard.php">
                <input type="hidden" name="search" value="<?= sanitize($search) ?>">
                <input type="hidden" name="sort" value="<?= sanitize($sort) ?>">
                <div class="categories-bar">
                    <button type="submit" name="category" value="0" class="category-pill <?= $categoryId === 0 ? 'active' : '' ?>">All</button>
                    <?php foreach ($categories as $category): ?>
                        <button type="submit" name="category" value="<?= sanitize((string)$category['id']) ?>" class="category-pill <?= $categoryId === (int)$category['id'] ? 'active' : '' ?>">
                            <?= sanitize($category['name']) ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </form>

            <div class="product-grid">
                <?php if (empty($products)): ?>
                    <div class="product-card">
                        <div class="product-body">
                            <p class="product-name">No products found.</p>
                            <p class="product-description">Try a different search or category.</p>
                        </div>
                    </div>
                <?php endif; ?>
                <?php foreach ($products as $product): ?>
                    <article class="product-card">
                        <div class="product-badge"><?= sanitize($product['category_name'] ?: 'Uncategorized') ?></div>
                        <div class="product-image"><?= sanitize($product['icon'] ?: '📦') ?></div>
                        <div class="product-body">
                            <h2 class="product-name"><?= sanitize($product['name']) ?></h2>
                            <p class="product-description"><?= sanitize(getProductDescription($product)) ?></p>
                            <div class="product-meta">
                                <span class="product-price">₱<?= number_format((float)$product['price'], 2) ?></span>
                                <span class="product-stock"><?= sanitize((string)$product['stock']) ?> in stock</span>
                            </div>
                        </div>
                        <form method="post" class="product-footer" style="padding: 0 18px 18px;">
                            <input type="hidden" name="action" value="add_to_cart">
                            <input type="hidden" name="product_id" value="<?= sanitize((string)$product['id']) ?>">
                            <button type="submit" class="add-button">Add to Cart</button>
                        </form>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <aside class="cart-card">
            <div class="cart-panel-header">
                <div>
                    <p class="eyebrow">Shopping cart</p>
                    <h2>Items in cart</h2>
                </div>
                <span class="cart-count"><?= sanitize((string)$cartItemCount) ?></span>
            </div>

            <?php if (empty($cartProducts)): ?>
                <div class="alert alert-light">Your cart is empty. Add products to see them here.</div>
            <?php else: ?>
                <form method="post">
                    <input type="hidden" name="action" value="update_cart">
                    <div class="cart-list">
                        <?php foreach ($cartProducts as $productId => $product): ?>
                            <?php $quantity = $cart[$productId] ?? 0; ?>
                            <div class="cart-item">
                                <div class="item-avatar"><?= sanitize($product['icon'] ?: '📦') ?></div>
                                <div class="cart-item-details">
                                    <strong><?= sanitize($product['name']) ?></strong>
                                    <small>₱<?= number_format((float)$product['price'], 2) ?> each</small>
                                    <small>Stock: <?= sanitize((string)$product['stock']) ?></small>
                                </div>
                                <div class="cart-item-actions">
                                    <input class="quantity-input" type="number" name="items[<?= sanitize((string)$productId) ?>]" min="0" max="<?= sanitize((string)$product['stock']) ?>" value="<?= sanitize((string)$quantity) ?>">
                                    <button type="button" class="cart-remove" onclick="removeCartItem(<?= sanitize((string)$productId) ?>)">Remove</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" class="btn btn-sm btn-outline-secondary mt-3">Update cart</button>
                </form>
                <?php foreach ($cartProducts as $productId => $product): ?>
                    <form method="post" class="d-none" id="remove-item-<?= sanitize((string)$productId) ?>">
                        <input type="hidden" name="action" value="remove_item">
                        <input type="hidden" name="product_id" value="<?= sanitize((string)$productId) ?>">
                    </form>
                <?php endforeach; ?>
                <script>
                function removeCartItem(productId) {
                    document.getElementById('remove-item-' + productId)?.submit();
                }
                </script>
                <div class="cart-summary">
                    <div class="summary-row">
                        <span>Total quantity</span>
                        <strong><?= sanitize((string)$cartTotals['quantity']) ?></strong>
                    </div>
                    <div class="summary-row">
                        <span>Subtotal</span>
                        <strong>₱<?= number_format($cartTotals['price'], 2) ?></strong>
                    </div>
                    <div class="summary-row">
                        <span>Checkout</span>
                        <a href="customer_checkout.php" class="btn btn-sm btn-primary">Proceed to checkout</a>
                    </div>
                </div>
            <?php endif; ?>
        </aside>
    </div>
</main>
</body>
</html>
