<?php
require_once __DIR__ . '/../config.php';

function isCustomerLoggedIn(): bool {
    return !empty($_SESSION['customer_id']);
}

function requireCustomerLogin(): void {
    if (!isCustomerLoggedIn()) {
        header('Location: customer_login.php');
        exit;
    }
}

function getCustomer(): array {
    if (!isCustomerLoggedIn()) {
        header('Location: customer_login.php');
        exit;
    }

    $stmt = db()->prepare('SELECT * FROM customers WHERE id = ? LIMIT 1');
    $stmt->execute([(int)$_SESSION['customer_id']]);
    $customer = $stmt->fetch();

    if (!$customer) {
        session_destroy();
        header('Location: customer_login.php');
        exit;
    }

    return $customer;
}

function getCustomerCart(): array {
    $cart = $_SESSION['customer_cart'] ?? [];
    return is_array($cart) ? $cart : [];
}

function setCustomerCart(array $cart): void {
    $_SESSION['customer_cart'] = $cart;
}

function getCartItemCount(array $cart): int {
    return array_sum(array_map('intval', $cart));
}

function fetchCartProducts(array $cart): array {
    if (empty($cart)) {
        return [];
    }

    $ids = array_keys($cart);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = db()->prepare("SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.id IN ($placeholders)");
    $stmt->execute($ids);
    $products = $stmt->fetchAll();

    $productsById = [];
    foreach ($products as $product) {
        $productsById[$product['id']] = $product;
    }

    return $productsById;
}

function fetchCategories(): array {
    $stmt = db()->query('SELECT id, name FROM categories ORDER BY name');
    return $stmt->fetchAll();
}

function fetchProducts(string $search = '', int $categoryId = 0, string $sort = 'newest'): array {
    $sql = 'SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE p.is_active = 1 AND p.stock > 0';
    $params = [];

    if ($search !== '') {
        $sql .= ' AND p.name LIKE ?';
        $params[] = '%' . $search . '%';
    }

    if ($categoryId > 0) {
        $sql .= ' AND p.category_id = ?';
        $params[] = $categoryId;
    }

    switch ($sort) {
        case 'price_asc':
            $sql .= ' ORDER BY p.price ASC';
            break;
        case 'price_desc':
            $sql .= ' ORDER BY p.price DESC';
            break;
        default:
            $sql .= ' ORDER BY p.created_at DESC';
            break;
    }

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function ensureCustomerOrderTables(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        customer_id INT(10) UNSIGNED NOT NULL,
        subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        delivery_method ENUM('Shipping','Pickup') NOT NULL DEFAULT 'Pickup',
        shipping_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        grand_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        full_name VARCHAR(150) DEFAULT NULL,
        phone VARCHAR(30) DEFAULT NULL,
        street_address VARCHAR(255) DEFAULT NULL,
        barangay VARCHAR(255) DEFAULT NULL,
        city VARCHAR(150) DEFAULT NULL,
        province VARCHAR(150) DEFAULT NULL,
        zip_code VARCHAR(20) DEFAULT NULL,
        status ENUM('Pending','To Ship','Received','Completed','Processing','Cancelled') NOT NULL DEFAULT 'Pending',
        order_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_customer_id (customer_id),
        CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_method ENUM('Shipping','Pickup') NOT NULL DEFAULT 'Pickup'");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipping_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS grand_total DECIMAL(10,2) NOT NULL DEFAULT 0.00");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS full_name VARCHAR(150) DEFAULT NULL");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS phone VARCHAR(30) DEFAULT NULL");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS street_address VARCHAR(255) DEFAULT NULL");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS barangay VARCHAR(255) DEFAULT NULL");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS city VARCHAR(150) DEFAULT NULL");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS province VARCHAR(150) DEFAULT NULL");
    db()->exec("ALTER TABLE orders ADD COLUMN IF NOT EXISTS zip_code VARCHAR(20) DEFAULT NULL");
    db()->exec("ALTER TABLE orders MODIFY COLUMN status ENUM('Pending','To Ship','Received','Completed','Processing','Cancelled') NOT NULL DEFAULT 'Pending'");

    db()->exec("CREATE TABLE IF NOT EXISTS order_items (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        order_id INT(10) UNSIGNED NOT NULL,
        product_id INT(10) UNSIGNED NOT NULL,
        quantity INT(10) UNSIGNED NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_order_id (order_id),
        INDEX idx_product_id (product_id),
        CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function getShippingFee(): float {
    return max(0.0, (float)getSetting('shipping_fee', '50.00'));
}

function getProductDescription(array $product): string {
    if (!empty($product['category_name'])) {
        return sprintf('Fresh %s from %s.', $product['name'], $product['category_name']);
    }
    return sprintf('Delicious %s prepared fresh for you.', $product['name']);
}
