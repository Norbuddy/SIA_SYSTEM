<?php
require_once __DIR__ . '/customer_common.php';
requireCustomerLogin();

function statusCssClass(string $status): string {
    return strtolower(str_replace([' ', '/'], ['-', '-'], trim($status)));
}

$customer = getCustomer();
$orders = [];

$stmt = db()->prepare(
    'SELECT o.id AS order_id, o.order_date, o.subtotal, o.shipping_fee, o.grand_total, o.delivery_method, o.full_name, o.phone, o.street_address, o.barangay, o.city, o.province, o.zip_code, o.status, oi.quantity, oi.unit_price, oi.total_price AS item_total, p.name AS product_name, p.icon AS product_icon
     FROM orders o
     JOIN order_items oi ON oi.order_id = o.id
     JOIN products p ON p.id = oi.product_id
     WHERE o.customer_id = ?
     ORDER BY o.order_date DESC, o.id DESC'
);
$stmt->execute([(int)$customer['id']]);
$rows = $stmt->fetchAll();
foreach ($rows as $row) {
    $orderId = $row['order_id'];
    if (!isset($orders[$orderId])) {
        $orders[$orderId] = [
            'order_id' => $orderId,
            'order_date' => $row['order_date'],
            'subtotal' => $row['subtotal'],
            'shipping_fee' => $row['shipping_fee'],
            'grand_total' => $row['grand_total'],
            'delivery_method' => $row['delivery_method'],
            'full_name' => $row['full_name'],
            'phone' => $row['phone'],
            'street_address' => $row['street_address'],
            'barangay' => $row['barangay'],
            'city' => $row['city'],
            'province' => $row['province'],
            'zip_code' => $row['zip_code'],
            'status' => $row['status'],
            'items' => [],
        ];
    }
    $orders[$orderId]['items'][] = [
        'name' => $row['product_name'],
        'icon' => $row['product_icon'],
        'quantity' => $row['quantity'],
        'unit_price' => $row['unit_price'],
        'item_total' => $row['item_total'],
    ];
}

$placed = !empty($_GET['placed']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="shop.css">
</head>
<body class="shop-page">
<header class="shop-topbar">
    <div class="brand"><?= sanitize(APP_NAME) ?> Market</div>
    <div class="shop-nav-actions">
        <span class="customer-name">Hello, <?= sanitize($customer['name']) ?></span>
        <a href="customer_dashboard.php" class="btn btn-sm btn-outline-secondary">Shop</a>
        <a href="customer_checkout.php" class="btn btn-sm btn-outline-secondary">Checkout</a>
        <a href="customer_dashboard.php?action=logout" class="btn btn-sm btn-danger">Logout</a>
    </div>
</header>
<main class="shop-container orders-page">
    <section class="orders-card">
        <div class="page-head">
            <div>
                <p class="eyebrow">Order history</p>
                <h1>Previous orders</h1>
                <p class="section-copy">Review your order status and purchased items.</p>
            </div>
        </div>

        <?php if ($placed): ?>
            <div class="alert alert-success">Your order has been placed successfully. View the details below.</div>
        <?php endif; ?>

        <?php if (empty($orders)): ?>
            <div class="alert alert-info">No orders found yet. Place an order from the shop.</div>
        <?php else: ?>
            <div class="orders-list">
                <?php foreach ($orders as $order): ?>
                    <article class="order-card">
                        <div class="order-header">
                            <div>
                                <p class="order-label">Order #<?= sanitize((string)$order['order_id']) ?></p>
                                <p class="order-date"><?= sanitize($order['order_date']) ?></p>
                            </div>
                            <div class="order-status <?= statusCssClass($order['status']) ?>"><?= sanitize($order['status']) ?></div>
                        </div>
                        <div class="order-meta" style="margin-bottom:18px">
                            <div style="display:flex;gap:12px;flex-wrap:wrap">
                                <span><strong>Method:</strong> <?= sanitize($order['delivery_method']) ?></span>
                                <span><strong>Subtotal:</strong> &#8369;<?= number_format($order['subtotal'], 2) ?></span>
                                <span><strong>Shipping:</strong> &#8369;<?= number_format($order['shipping_fee'], 2) ?></span>
                                <span><strong>Total:</strong> &#8369;<?= number_format($order['grand_total'], 2) ?></span>
                            </div>
                        </div>
                        <?php if ($order['delivery_method'] === 'Shipping'): ?>
                        <div class="order-address" style="margin-bottom:16px;padding:14px;border-radius:16px;background:#f8f9fa">
                            <div style="font-weight:700;margin-bottom:6px">Shipping Address</div>
                            <div><?= sanitize($order['full_name']) ?></div>
                            <div><?= sanitize($order['street_address']) ?>, <?= sanitize($order['barangay']) ?></div>
                            <div><?= sanitize($order['city']) ?>, <?= sanitize($order['province']) ?> <?= sanitize($order['zip_code']) ?></div>
                            <div>Phone: <?= sanitize($order['phone']) ?></div>
                        </div>
                        <?php endif; ?>
                        <div class="order-items">
                            <?php foreach ($order['items'] as $item): ?>
                                <div class="order-item">
                                    <span class="item-icon"><?= sanitize($item['icon'] ?: '📦') ?></span>
                                    <div>
                                        <strong><?= sanitize($item['name']) ?></strong>
                                        <small><?= sanitize($item['quantity']) ?> × &#8369;<?= number_format($item['unit_price'], 2) ?></small>
                                    </div>
                                    <strong>&#8369;<?= number_format($item['item_total'], 2) ?></strong>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="order-footer">
                            <span>Total</span>
                            <strong>&#8369;<?= number_format($order['grand_total'], 2) ?></strong>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
