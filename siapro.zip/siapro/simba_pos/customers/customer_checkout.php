<?php
require_once __DIR__ . '/customer_common.php';
requireCustomerLogin();
ensureCustomerOrderTables();

$customer = getCustomer();
$cart = getCustomerCart();
$errors = [];
$placedOrderId = null;

$cartProducts = fetchCartProducts($cart);
$cartTotals = [
    'quantity' => 0,
    'price' => 0.0,
];
foreach ($cart as $productId => $quantity) {
    if (!isset($cartProducts[$productId])) {
        continue;
    }
    $product = $cartProducts[$productId];
    $subtotal = $product['price'] * $quantity;
    $cartTotals['quantity'] += $quantity;
    $cartTotals['price'] += $subtotal;
}

$deliveryMethod = $_POST['delivery_method'] ?? 'Pickup';
$fullName = trim($_POST['full_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$streetAddress = trim($_POST['street_address'] ?? '');
$barangay = trim($_POST['barangay'] ?? '');
$city = trim($_POST['city'] ?? '');
$province = trim($_POST['province'] ?? '');
$zipCode = trim($_POST['zip_code'] ?? '');
$shippingFee = getShippingFee();
$grandTotal = $cartTotals['price'] + ($deliveryMethod === 'Shipping' ? $shippingFee : 0.0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($cartProducts)) {
        $errors[] = 'Your cart is empty. Add items before checking out.';
    }

    if ($deliveryMethod === 'Shipping') {
        if (!$fullName)      $errors[] = 'Full name is required for shipping.';
        if (!$phone)         $errors[] = 'Phone number is required for shipping.';
        if (!$streetAddress) $errors[] = 'Street address is required for shipping.';
        if (!$barangay)      $errors[] = 'Barangay is required for shipping.';
        if (!$city)          $errors[] = 'City/Municipality is required for shipping.';
        if (!$province)      $errors[] = 'Province is required for shipping.';
        if (!$zipCode)       $errors[] = 'ZIP code is required for shipping.';
    }

    if (empty($errors)) {
        try {
            db()->beginTransaction();
            $subtotal = 0.0;
            $preparedProducts = [];

            foreach ($cart as $productId => $quantity) {
                if ($quantity < 1) {
                    continue;
                }

                $stmt = db()->prepare('SELECT * FROM products WHERE id = ? FOR UPDATE');
                $stmt->execute([$productId]);
                $product = $stmt->fetch();

                if (!$product) {
                    throw new Exception('A product in your cart is no longer available.');
                }
                if ($product['stock'] < $quantity) {
                    throw new Exception(sprintf('Not enough stock for %s. Available: %d', $product['name'], $product['stock']));
                }

                $lineTotal = $product['price'] * $quantity;
                $preparedProducts[] = [
                    'id' => $product['id'],
                    'name' => $product['name'],
                    'quantity' => $quantity,
                    'unit_price' => (float)$product['price'],
                    'subtotal' => $lineTotal,
                ];
                $subtotal += $lineTotal;
            }

            if (empty($preparedProducts)) {
                throw new Exception('Your cart contains no valid items.');
            }

            $shippingFee = $deliveryMethod === 'Shipping' ? getShippingFee() : 0.0;
            $grandTotal = $subtotal + $shippingFee;

            $stmt = db()->prepare('INSERT INTO orders (customer_id, subtotal, delivery_method, shipping_fee, grand_total, full_name, phone, street_address, barangay, city, province, zip_code, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                (int)$customer['id'],
                $subtotal,
                $deliveryMethod,
                $shippingFee,
                $grandTotal,
                $deliveryMethod === 'Shipping' ? $fullName : null,
                $deliveryMethod === 'Shipping' ? $phone : null,
                $deliveryMethod === 'Shipping' ? $streetAddress : null,
                $deliveryMethod === 'Shipping' ? $barangay : null,
                $deliveryMethod === 'Shipping' ? $city : null,
                $deliveryMethod === 'Shipping' ? $province : null,
                $deliveryMethod === 'Shipping' ? $zipCode : null,
                'Pending',
            ]);
            $placedOrderId = (int)db()->lastInsertId();

            $itemStmt = db()->prepare('INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price) VALUES (?, ?, ?, ?, ?)');
            $stockStmt = db()->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');

            foreach ($preparedProducts as $product) {
                $itemStmt->execute([
                    $placedOrderId,
                    $product['id'],
                    $product['quantity'],
                    $product['unit_price'],
                    $product['subtotal'],
                ]);
                $stockStmt->execute([$product['quantity'], $product['id']]);
            }

            db()->commit();
            setCustomerCart([]);
            header('Location: customer_orders.php?placed=1');
            exit;
        } catch (Exception $e) {
            db()->rollBack();
            $errors[] = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="shop.css">
</head>
<body class="shop-page">
<header class="shop-topbar">
    <div class="brand"><?= sanitize(APP_NAME) ?> Market</div>
    <div class="shop-nav-actions">
        <span class="customer-name">Hello, <?= sanitize($customer['name']) ?></span>
        <a href="customer_dashboard.php" class="btn btn-sm btn-outline-secondary">Continue Shopping</a>
        <a href="customer_orders.php" class="btn btn-sm btn-outline-secondary">My Orders</a>
        <a href="customer_dashboard.php?action=logout" class="btn btn-sm btn-danger">Logout</a>
    </div>
</header>
<main class="shop-container">
    <section class="checkout-card">
        <div class="page-head">
            <div>
                <p class="eyebrow">Checkout</p>
                <h1>Your order summary</h1>
                <p class="section-copy">Review your items before placing the order.</p>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger"><?= sanitize(implode(' ', $errors)) ?></div>
        <?php endif; ?>

        <?php if (empty($cartProducts)): ?>
            <div class="alert alert-warning">Your cart is empty. Add products from the shop first.</div>
        <?php else: ?>
            <div class="order-preview">
                <?php foreach ($cart as $productId => $quantity): ?>
                    <?php if (!isset($cartProducts[$productId])) { continue; } ?>
                    <?php $product = $cartProducts[$productId]; ?>
                    <div class="preview-item">
                        <div class="item-meta">
                            <span class="item-image"><?= sanitize($product['icon'] ?: '📦') ?></span>
                            <div>
                                <strong><?= sanitize($product['name']) ?></strong>
                                <p><?= sanitize(getProductDescription($product)) ?></p>
                            </div>
                        </div>
                        <div class="item-right">
                            <span><?= sanitize($quantity) ?> × <?= number_format((float)$product['price'], 2) ?></span>
                            <strong><?= number_format($product['price'] * $quantity, 2) ?></strong>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <form method="post" class="checkout-form">
                <div class="mb-4">
                    <label class="form-label">Delivery method</label>
                    <div class="d-flex gap-3">
                        <label class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="delivery_method" value="Pickup" <?= $deliveryMethod !== 'Shipping' ? 'checked' : '' ?> onchange="toggleShippingFields()">
                            <span class="form-check-label">Store Pickup</span>
                        </label>
                        <label class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="delivery_method" value="Shipping" <?= $deliveryMethod === 'Shipping' ? 'checked' : '' ?> onchange="toggleShippingFields()">
                            <span class="form-check-label">Ship to Address</span>
                        </label>
                    </div>
                </div>

                <div id="shipping-fields" style="display: <?= $deliveryMethod === 'Shipping' ? 'block' : 'none' ?>;">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input class="form-control" type="text" name="full_name" value="<?= sanitize($fullName) ?>" placeholder="Full Name">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input class="form-control" type="text" name="phone" value="<?= sanitize($phone) ?>" placeholder="0912 345 6789">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Street Address</label>
                        <input class="form-control" type="text" name="street_address" value="<?= sanitize($streetAddress) ?>" placeholder="1234 Journey St.">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Barangay</label>
                        <input class="form-control" type="text" name="barangay" value="<?= sanitize($barangay) ?>" placeholder="Barangay">
                    </div>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">City/Municipality</label>
                            <input class="form-control" type="text" name="city" value="<?= sanitize($city) ?>" placeholder="City">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Province</label>
                            <input class="form-control" type="text" name="province" value="<?= sanitize($province) ?>" placeholder="Province">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">ZIP Code</label>
                            <input class="form-control" type="text" name="zip_code" value="<?= sanitize($zipCode) ?>" placeholder="ZIP Code">
                        </div>
                    </div>
                </div>

                <div class="checkout-summary">
                    <div>
                        <span>Subtotal</span>
                        <strong>&#8369;<?= number_format($cartTotals['price'], 2) ?></strong>
                    </div>
                    <?php if ($deliveryMethod === 'Shipping'): ?>
                    <div>
                        <span>Shipping Fee</span>
                        <strong>&#8369;<?= number_format($shippingFee, 2) ?></strong>
                    </div>
                    <?php endif; ?>
                    <div>
                        <span>Total</span>
                        <strong>&#8369;<?= number_format($grandTotal, 2) ?></strong>
                    </div>
                </div>

                <button type="submit" name="place_order" class="btn btn-primary btn-lg">Place order</button>
            </form>
        <?php endif; ?>

        <script>
        function toggleShippingFields() {
            const method = document.querySelector('input[name="delivery_method"]:checked')?.value;
            const shipping = document.getElementById('shipping-fields');
            if (shipping) {
                shipping.style.display = method === 'Shipping' ? 'block' : 'none';
            }
        }
        </script>
    </section>
</main>
</body>
</html>
