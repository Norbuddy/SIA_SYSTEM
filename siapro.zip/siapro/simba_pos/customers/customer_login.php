<?php
require_once __DIR__ . '/../config.php';
header('Location: ../index.php');
exit;

function ensure_customers_table(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS customers (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        username VARCHAR(100) NOT NULL UNIQUE,
        phone VARCHAR(30) DEFAULT '',
        password VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT current_timestamp()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $column = db()->query("SHOW COLUMNS FROM customers LIKE 'username'")->fetch();
    if (!$column) {
        db()->exec("ALTER TABLE customers ADD COLUMN username VARCHAR(100) NOT NULL UNIQUE AFTER email");
    }
}

if (!empty($_SESSION['customer_id'])) {
    header('Location: customer_dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$identifier) {
        $errors[] = 'Email or username is required.';
    }

    if (!$password) {
        $errors[] = 'Password is required.';
    }

    if (empty($errors)) {
        try {
            ensure_customers_table();
            $stmt = db()->prepare('SELECT * FROM customers WHERE email = ? OR username = ? LIMIT 1');
            $stmt->execute([$identifier, $identifier]);
            $customer = $stmt->fetch();

            if (!$customer || !password_verify($password, $customer['password'])) {
                $errors[] = 'Invalid email/username or password.';
            } else {
                session_regenerate_id(true);
                $_SESSION['customer_id'] = (int)$customer['id'];
                $_SESSION['customer_name'] = $customer['name'];
                $_SESSION['customer_email'] = $customer['email'];
                $_SESSION['customer_username'] = $customer['username'];
                header('Location: customer_dashboard.php');
                exit;
            }
        } catch (Exception $e) {
            $errors[] = 'Unable to sign in. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Login — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body class="auth-page">
<div class="auth-bg">
    <div class="blob blob-1"></div>
    <div class="blob blob-2"></div>

    <div class="auth-card" style="max-width:420px;">
        <div class="a-logo">
            <div class="a-ico"><i class="bi bi-person-circle"></i></div>
            <div>
                <h1>Customer Login</h1>
                <span>Sign in to view your dashboard</span>
            </div>
        </div>

        <?php if (!empty($_GET['registered'])): ?>
            <div class="alert-box ok mb-3">
                <i class="bi bi-check-circle-fill"></i> Registration complete. Please sign in.
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert-box err mb-3">
                <i class="bi bi-exclamation-circle-fill"></i> <?= sanitize(implode(' ', $errors)) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="customer_login.php" autocomplete="off">
            <div class="fg">
                <label class="a-lbl">Email or Username</label>
                <input class="a-inp" type="text" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="you@example.com or username" required>
            </div>
            <div class="fg">
                <label class="a-lbl">Password</label>
                <div class="a-inp-wrap">
                    <input class="a-inp" type="password" name="password" id="c-pw" placeholder="••••••••" required>
                    <i class="bi bi-eye eye" onclick="tpw('c-pw', this)"></i>
                </div>
            </div>
            <button type="submit" class="btn-a mt-2">
                <i class="bi bi-box-arrow-in-right"></i> Login
            </button>
        </form>

        <div class="text-center mt-3">
            <a class="a-lnk" href="customer_register.php">New customer? Create account</a>
        </div>
        <div class="text-center mt-3">
            <a class="a-lnk" href="../admin/index.php">Back to staff login</a>
        </div>
    </div>
</div>
<script>
function tpw(id, el) {
    const input = document.getElementById(id);
    if (!input) return;
    if (input.type === 'password') {
        input.type = 'text';
        el.classList.remove('bi-eye');
        el.classList.add('bi-eye-slash');
    } else {
        input.type = 'password';
        el.classList.remove('bi-eye-slash');
        el.classList.add('bi-eye');
    }
}
</script>
</body>
</html>
