<?php
require_once __DIR__ . '/../config.php';
header('Location: ../index.php#register');
exit;

function ensure_customers_table(): void {
    db()->exec("CREATE TABLE IF NOT EXISTS customers (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        username VARCHAR(100) NOT NULL UNIQUE,
        phone VARCHAR(30) DEFAULT '',
        password VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT current_timestamp()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $column = db()->query("SHOW COLUMNS FROM customers LIKE 'username'")->fetch();
    if (!$column) {
        db()->exec("ALTER TABLE customers ADD COLUMN username VARCHAR(100) NOT NULL UNIQUE AFTER email");
    }
}

function generateCustomerUsername(string $email): string {
    $base = strtolower(preg_replace('/[^a-z0-9]/', '', strstr($email, '@', true) ?: $email));
    $username = $base ?: 'customer';
    $suffix = 0;

    while (true) {
        $candidate = $username . ($suffix ? $suffix : '');
        $stmt = db()->prepare('SELECT id FROM customers WHERE username = ? LIMIT 1');
        $stmt->execute([$candidate]);
        if (!$stmt->fetch()) {
            return $candidate;
        }
        $suffix++;
    }
}

if (!empty($_SESSION['customer_id'])) {
    header('Location: customer_dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (!$name) {
        $errors[] = 'Name is required.';
    }
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email is required.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        try {
            ensure_customers_table();
            $chk = db()->prepare('SELECT id FROM customers WHERE email = ? LIMIT 1');
            $chk->execute([$email]);
            if ($chk->fetch()) {
                $errors[] = 'That email is already registered.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $username = generateCustomerUsername($email);
                $stmt = db()->prepare('INSERT INTO customers (name, email, username, phone, password) VALUES (?, ?, ?, ?, ?)');
                $stmt->execute([$name, $email, $username, $phone, $hash]);
                header('Location: customer_login.php?registered=1');
                exit;
            }
        } catch (Exception $e) {
            $errors[] = 'Unable to register. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Register — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body class="auth-page">
<div class="auth-bg">
    <div class="blob blob-1"></div>
    <div class="blob blob-2"></div>
    <div class="auth-card" style="max-width:480px;">
        <div class="a-logo">
            <div class="a-ico"><i class="bi bi-pencil-fill"></i></div>
            <div>
                <h1>Create Account</h1>
                <span>Register as a customer</span>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="alert-box err mb-3">
                <i class="bi bi-exclamation-circle-fill"></i> <?= sanitize(implode(' ', $errors)) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="customer_register.php" autocomplete="off">
            <div class="fg">
                <label class="a-lbl">Full Name</label>
                <input class="a-inp" type="text" name="name" value="<?= sanitize($_POST['name'] ?? '') ?>" placeholder="Juan dela Cruz" required>
            </div>
            <div class="fg">
                <label class="a-lbl">Email Address</label>
                <input class="a-inp" type="email" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="you@example.com" required>
            </div>
            <div class="fg">
                <label class="a-lbl">Phone (optional)</label>
                <input class="a-inp" type="text" name="phone" value="<?= sanitize($_POST['phone'] ?? '') ?>" placeholder="0912 345 6789">
            </div>
            <div class="fg">
                <label class="a-lbl">Password</label>
                <div class="a-inp-wrap">
                    <input class="a-inp" type="password" name="password" id="r-pw1" placeholder="Min 6 characters" required>
                    <i class="bi bi-eye eye" onclick="tpw('r-pw1', this)"></i>
                </div>
            </div>
            <div class="fg">
                <label class="a-lbl">Confirm Password</label>
                <div class="a-inp-wrap">
                    <input class="a-inp" type="password" name="confirm" id="r-pw2" required>
                    <i class="bi bi-eye eye" onclick="tpw('r-pw2', this)"></i>
                </div>
            </div>
            <button type="submit" class="btn-a mt-2">
                <i class="bi bi-person-plus-fill"></i> Register
            </button>
        </form>

        <div class="text-center mt-3">
            <a class="a-lnk" href="customer_login.php">Already have an account? Login</a>
        </div>
        <div class="text-center mt-3">
            <a class="a-lnk" href="../admin/index.php">Back to staff login</a>
        </div>
    </div>
</div>
<script>
function tpw(id, el) {
    const input = document.getElementById(id);
    if (!input) return;
    if (input.type === 'password') {
        input.type = 'text';
        el.classList.remove('bi-eye');
        el.classList.add('bi-eye-slash');
    } else {
        input.type = 'password';
        el.classList.remove('bi-eye-slash');
        el.classList.add('bi-eye');
    }
}
</script>
</body>
</html>
