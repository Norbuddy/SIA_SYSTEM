<?php
// One-off helper to set the `admin` user's password. Only allowed on localhost.
// Usage: http://localhost/your_project/tools/set_admin_password.php?pw=admin123

require_once __DIR__ . '/../config.php';

if (PHP_SAPI === 'cli') {
    echo "Run this from the browser on localhost.\n";
    exit;
}

$host = $_SERVER['HTTP_HOST'] ?? '';
$hostOnly = preg_replace('/:.+$/', '', $host);
$allowed = ['localhost', '127.0.0.1', '::1'];
if (!in_array($hostOnly, $allowed, true)) {
    http_response_code(403);
    echo 'Forbidden: this script can only be run from localhost.';
    exit;
}

$pw = $_GET['pw'] ?? '';
if (!$pw) {
    echo '<h1>Set admin password</h1>';
    echo '<form><input name="pw" placeholder="new password"><button type="submit">Set password</button></form>';
    exit;
}

try {
    $hash = password_hash($pw, PASSWORD_BCRYPT);
    $stmt = db()->prepare('UPDATE users SET password = ? WHERE username = ?');
    $stmt->execute([$hash, 'admin']);
    echo '<h1>Success</h1><p>Admin password updated. Please delete this file after use.</p>';
} catch (Exception $e) {
    http_response_code(500);
    echo '<h1>Error</h1><pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
}
