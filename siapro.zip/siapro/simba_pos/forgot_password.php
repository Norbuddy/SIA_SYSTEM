<?php
// ============================================================
// forgot_password.php — Request a password reset link
// ============================================================
require_once __DIR__ . '/config.php';

if (isLoggedIn()) { header('Location: cashier_dashboard.php'); exit; }

$err = $msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));

    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Please enter a valid email address.';
    } else {
        $stmt = db()->prepare("SELECT id, name FROM users WHERE email=? AND status='active' LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            // Generate a secure token valid for 1 hour
            $token = bin2hex(random_bytes(32));
            $exp   = date('Y-m-d H:i:s', time() + 3600);
            $upd   = db()->prepare('UPDATE users SET reset_token=?, reset_exp=? WHERE id=?');
            $upd->execute([$token, $exp, $user['id']]);

            // In a real app you'd send this via email (PHPMailer / SendGrid etc.)
            // For demo: display the reset link directly.
            $resetLink = (isset($_SERVER['HTTPS']) ? 'https' : 'http')
                       . '://' . $_SERVER['HTTP_HOST']
                       . dirname($_SERVER['REQUEST_URI'])
                       . '/reset_password.php?token=' . $token;

            $msg = 'A reset link has been generated. '
                 . '<a href="' . htmlspecialchars($resetLink) . '" style="color:var(--orange)">'
                 . 'Click here to reset your password</a>.'
                 . '<br><small style="opacity:.7">(In production this link would be emailed to you.)</small>';
        } else {
            // Don't reveal whether email exists — generic message
            $msg = 'If that email is registered, a reset link has been sent.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — Simba Cafe POS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-page">
<div class="auth-bg">
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>

  <div class="auth-card" style="max-width:420px">
    <div class="a-logo">
      <div class="a-ico"><i class="bi bi-cup-hot-fill"></i></div>
      <div><h1>Simba Cafe</h1><span>Password Recovery</span></div>
    </div>

    <h2 class="a-title">Forgot your password?</h2>
    <p class="a-sub">Enter your account email and we'll generate a reset link for you.</p>

    <?php if ($err): ?>
    <div class="alert-box err mb-3"><i class="bi bi-exclamation-circle-fill"></i> <?= sanitize($err) ?></div>
    <?php endif; ?>
    <?php if ($msg): ?>
    <div class="alert-box ok mb-3"><i class="bi bi-check-circle-fill"></i> <?= $msg /* trusted HTML */ ?></div>
    <?php endif; ?>

    <?php if (!$msg): ?>
    <form method="POST" autocomplete="off">
      <div class="fg">
        <label class="a-lbl">Email Address</label>
        <input class="a-inp" type="email" name="email"
               value="<?= sanitize($_POST['email'] ?? '') ?>"
               placeholder="you@simbacafe.com" required autofocus>
      </div>
      <button type="submit" class="btn-a mt-2">
        <i class="bi bi-send-fill"></i> Send Reset Link
      </button>
    </form>
    <?php endif; ?>

    <div class="text-center mt-3">
      <a class="a-lnk" href="index.php">
        <i class="bi bi-arrow-left"></i> Back to Login
      </a>
    </div>
  </div>
</div>
</body>
</html>