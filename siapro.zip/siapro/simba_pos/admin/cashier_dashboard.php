<?php
// ============================================================
// cashier_dashboard.php — Main POS interface for all roles
// ============================================================
require_once __DIR__ . '/../config.php';
requireCashier();

$user       = currentUser();
$pdo        = db();
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order")->fetchAll();
$products   = $pdo->query("
    SELECT p.*, c.name as cat_name
    FROM products p
    JOIN categories c ON p.category_id=c.id
    WHERE p.is_active=1
    ORDER BY c.sort_order, p.name
")->fetchAll();
$taxRate    = (float)getSetting('tax_rate', '10') / 100;
$cafeName   = getSetting('cafe_name', 'Simba Cafe');
$cafeAddr   = getSetting('cafe_address', '');
$cafePhone  = getSetting('cafe_phone', '');
$currency   = getSetting('currency', '$');

// Admin-level privileges only
$isAdmin = $user['role'] === 'admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>POS — <?= sanitize($cafeName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="../style.css">
</head>
<body class="shell-page">

<!-- ════ TOPBAR ════ -->
<div class="topbar">
  <div class="brand"><i class="bi bi-cup-hot-fill"></i> <?= sanitize($cafeName) ?> POS</div>
  <div class="t-spacer"></div>

  <!-- Navigation buttons in topbar -->
  <button class="t-btn me-1" onclick="showPanel('pos')" id="nav-pos">
    <i class="bi bi-grid-fill"></i> POS
  </button>
  <button class="t-btn me-1" onclick="showPanel('inventory')" id="nav-inventory">
    <i class="bi bi-box-seam-fill"></i> Inventory
  </button>
  <button class="t-btn me-1" onclick="showPanel('history')" id="nav-history">
    <i class="bi bi-clock-history"></i> Transactions
  </button>
  <button class="t-btn me-1" onclick="showPanel('orders')" id="nav-orders">
    <i class="bi bi-bag-check"></i> Orders
  </button>
  <button class="t-btn me-2" onclick="showPanel('profile')" id="nav-profile">
    <i class="bi bi-person-circle"></i> Profile
  </button>

  <span class="t-usr"><?= sanitize($user['name']) ?> (<?= sanitize($user['role']) ?>)</span>
  <a href="logout.php" class="t-btn"><i class="bi bi-box-arrow-right"></i> Sign out</a>
</div>

<!-- ════ PANELS CONTAINER ════ -->
<div id="panel-wrap" style="height:calc(100vh - 52px);position:relative;overflow:hidden">

  <!-- ════════════════════════════════════
       POS PANEL
  ═══════════════════════════════════════ -->
  <div id="panel-pos" class="pos-panel">
  <div class="pos-wrap">

    <!-- LEFT: Category sidebar + Product grid -->
    <div class="pos-left">
      <!-- Search bar -->
      <div class="pos-top">
        <div class="pos-srch">
          <i class="bi bi-search"></i>
          <input type="text" id="pos-q" placeholder="Search products…" oninput="filterPOS()">
        </div>
        <span style="font-size:.78rem;color:#aaa;margin-left:auto">
          Tax: <?= round($taxRate*100) ?>%
        </span>
      </div>

      <div class="pos-body">
        <!-- Category sidebar -->
        <div class="cat-side" id="cat-side">
          <div class="cat-itm on" data-cat="all" onclick="setCategory('all',this)">
            <span class="c-ico">🔶</span>
            <span class="c-lbl">All Items</span>
          </div>
          <?php foreach ($categories as $c): ?>
          <div class="cat-itm" data-cat="<?= $c['id'] ?>" onclick="setCategory('<?= $c['id'] ?>',this)">
            <span class="c-ico"><?= $c['icon'] ?></span>
            <span class="c-lbl"><?= sanitize($c['name']) ?></span>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Product grid -->
        <div class="prod-area">
          <div class="prod-grid" id="prod-grid">
            <?php foreach ($products as $p): ?>
            <div class="p-card <?= $p['stock'] == 0 ? 'p-out' : '' ?>"
                 data-cat="<?= $p['category_id'] ?>"
                 data-name="<?= strtolower(sanitize($p['name'])) ?>"
                 data-id="<?= $p['id'] ?>"
                 data-price="<?= $p['price'] ?>"
                 data-stock="<?= $p['stock'] ?>"
                 onclick="addToOrder(<?= $p['id'] ?>)"
                 title="<?= $p['stock'] == 0 ? 'Out of stock' : 'Add to order' ?>">
              <span class="p-emo"><?= $p['icon'] ?></span>
              <div class="p-name"><?= sanitize($p['name']) ?></div>
              <div class="p-price"><?= $currency ?><?= number_format($p['price'], 2) ?></div>
              <?php if ($p['stock'] == 0): ?>
              <div class="p-status out">OUT OF STOCK</div>
              <?php elseif ($p['stock'] < 10): ?>
              <div class="p-status low">Low: <?= $p['stock'] ?> left</div>
              <?php endif; ?>
            </div>
            <?php endforeach; ?>
          </div>
          <div id="no-prod" style="display:none;text-align:center;padding:60px 20px;color:#bbb">
            <i class="bi bi-search" style="font-size:2.4rem;display:block;margin-bottom:10px"></i>
            No products found.
          </div>
        </div>
      </div>
    </div>

    <!-- RIGHT: Order panel -->
    <div class="pos-right">
      <div class="ord-hdr">
        <h3><i class="bi bi-bag-fill me-1" style="color:var(--orange)"></i> Current Order</h3>
        <button class="btn-clr" onclick="clearOrder()">Clear All</button>
      </div>

      <!-- Order column headers -->
      <div class="ord-cols">
        <span class="ord-col-lbl">Item</span>
        <span class="ord-col-lbl" style="text-align:center">Qty</span>
        <span class="ord-col-lbl" style="text-align:right">Cost</span>
      </div>

      <!-- Order line items -->
      <div class="ord-tbl-wrap">
        <div id="ord-body">
          <div class="ord-empty" id="ord-empty">
            <i class="bi bi-bag-x" style="font-size:2rem;display:block;margin-bottom:8px;color:#ddd"></i>
            No items yet.<br>
            <small style="font-size:.72rem;color:#ccc">Tap a product to add.</small>
          </div>
        </div>
      </div>

      <!-- Totals + checkout -->
      <div class="ord-foot">
        <div class="disc-row">
          <input type="number" class="disc-inp" id="disc" min="0" max="100" step="0.1" placeholder="Discount %">
          <button class="disc-btn" onclick="applyDiscount()">Apply</button>
        </div>
        <div class="tot-row"><span>Subtotal</span><span id="lbl-sub"><?= $currency ?>0.00</span></div>
        <div class="tot-row"><span>Tax (<?= round($taxRate*100) ?>%)</span><span id="lbl-tax"><?= $currency ?>0.00</span></div>
        <div class="tot-row"><span>Discount</span><span id="lbl-disc">-<?= $currency ?>0.00</span></div>
        <hr class="tot-div">
        <div class="tot-row big"><span>TOTAL</span><span id="lbl-tot"><?= $currency ?>0.00</span></div>
        <button class="btn-pay" id="btn-pay" onclick="openPayModal()" disabled>
          <i class="bi bi-cash-stack"></i> Pay
        </button>
      </div>
    </div>
  </div>
  </div><!-- /panel-pos -->

  <!-- ════════════════════════════════════
       INVENTORY PANEL
  ═══════════════════════════════════════ -->
  <div id="panel-inventory" class="pos-panel" style="display:none;overflow-y:auto;background:#f0f2f5;padding:22px">

    <div class="pg-hdr">
      <div><h2>Inventory</h2><p>Manage products and stock levels</p></div>
      <?php if ($isAdmin): ?>
      <div style="display:flex;gap:8px">
        <button class="btn-p" onclick="openCatModal()"><i class="bi bi-tag-fill"></i> Add Category</button>
        <button class="btn-p" onclick="openProdModal()"><i class="bi bi-plus-lg"></i> Add Product</button>
      </div>
      <?php endif; ?>
    </div>

    <!-- Stock summary cards -->
    <div class="row g-3 mb-3" id="inv-summary">
      <?php
      $invProducts = $pdo->query("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id=c.id ORDER BY p.stock ASC, p.name")->fetchAll();
      $outCnt = count(array_filter($invProducts, fn($p) => (int)$p['stock'] === 0));
      $lowCnt = count(array_filter($invProducts, fn($p) => (int)$p['stock'] > 0 && (int)$p['stock'] < 10));
      $okCnt  = count(array_filter($invProducts, fn($p) => (int)$p['stock'] >= 10));
      ?>
      <div class="col-md-4"><div class="s-card">
        <div class="s-ico" style="background:rgba(239,71,111,.1);color:#ef476f"><i class="bi bi-x-circle-fill"></i></div>
        <div class="s-val" style="color:#ef476f"><?= $outCnt ?></div><div class="s-lbl">Out of Stock</div>
      </div></div>
      <div class="col-md-4"><div class="s-card">
        <div class="s-ico" style="background:rgba(255,209,102,.2);color:#b45309"><i class="bi bi-exclamation-triangle-fill"></i></div>
        <div class="s-val" style="color:#b45309"><?= $lowCnt ?></div><div class="s-lbl">Low Stock (&lt;10)</div>
      </div></div>
      <div class="col-md-4"><div class="s-card">
        <div class="s-ico" style="background:rgba(6,214,160,.1);color:#059669"><i class="bi bi-check-circle-fill"></i></div>
        <div class="s-val" style="color:#059669"><?= $okCnt ?></div><div class="s-lbl">In Stock</div>
      </div></div>
    </div>

    <!-- Product Table -->
    <div class="panel">
      <div class="ptitle" style="margin-bottom:12px">
        Products
        <div class="srch-bar">
          <i class="bi bi-search"></i>
          <input type="text" id="inv-search" placeholder="Search…" oninput="filterInvTable()">
        </div>
      </div>
      <div style="overflow-x:auto">
        <table class="tbl" id="inv-table">
          <thead>
            <tr>
              <th>Icon</th><th>Name</th><th>Category</th>
              <th>Price</th><th>Stock</th><th>Availability</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody id="inv-tbody">
          <?php foreach ($invProducts as $p): ?>
          <tr data-id="<?= $p['id'] ?>" data-name="<?= strtolower(sanitize($p['name'])) ?>">
            <td style="font-size:1.4rem"><?= $p['icon'] ?></td>
            <td style="font-weight:600"><?= sanitize($p['name']) ?></td>
            <td><?= sanitize($p['cat_name']) ?></td>
            <td style="font-weight:700;color:var(--orange)"><?= $currency ?><?= number_format($p['price'], 2) ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:5px">
                <input type="number" class="fc" id="stk-<?= $p['id'] ?>" value="<?= $p['stock'] ?>"
                       min="0" style="width:70px;padding:5px 8px;font-size:.8rem">
                <button class="btn-ed be" onclick="doUpdateStock(<?= $p['id'] ?>)" title="Update stock">
                  <i class="bi bi-check-lg"></i>
                </button>
              </div>
            </td>
            <td>
              <span class="bdg <?= (int)$p['is_active'] === 1 ? 'stk-ok' : 'stk-out' ?>">
                <?= (int)$p['is_active'] === 1 ? 'Available' : 'Unavailable' ?>
              </span>
            </td>
            <td>
              <span class="bdg <?= (int)$p['stock'] === 0 ? 'stk-out' : ((int)$p['stock'] < 10 ? 'stk-lo' : 'stk-ok') ?>">
                <?= (int)$p['stock'] === 0 ? 'Out' : ((int)$p['stock'] < 10 ? 'Low' : 'OK') ?>
              </span>
            </td>
            <td>
              <button class="btn-ed be" onclick="doUpdateStock(<?= $p['id'] ?>)" title="Update stock">
                <i class="bi bi-check-lg"></i>
              </button>
              <button class="btn-ed bd ms-1 availability-btn" onclick="toggleProductAvailability(<?= $p['id'] ?>, <?= (int)$p['is_active'] ?>)" title="Toggle availability">
                <?= (int)$p['is_active'] === 1 ? 'Mark Unavailable' : 'Mark Available' ?>
              </button>
              <?php if ($isAdmin): ?>
              <button class="btn-ed be ms-1" onclick='openProdModal(<?= json_encode($p) ?>)'>Edit</button>
              <button class="btn-ed bd ms-1" onclick="deleteProd(<?= $p['id'] ?>, '<?= sanitize($p['name']) ?>')">Delete</button>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Categories Table (admin only) -->
    <?php if ($isAdmin): ?>
    <div class="panel mt-3">
      <div class="ptitle">Categories</div>
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead><tr><th>Icon</th><th>Name</th><th>Sort Order</th><th>Products</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach ($categories as $c):
            $cnt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id=?');
            $cnt->execute([$c['id']]);
            $prodCount = $cnt->fetchColumn();
          ?>
          <tr>
            <td style="font-size:1.4rem"><?= $c['icon'] ?></td>
            <td style="font-weight:600"><?= sanitize($c['name']) ?></td>
            <td><?= $c['sort_order'] ?></td>
            <td><?= $prodCount ?></td>
            <td>
              <button class="btn-ed be" onclick='openCatModal(<?= json_encode($c) ?>)'>Edit</button>
              <button class="btn-ed bd ms-1" onclick="deleteCat(<?= $c['id'] ?>, '<?= sanitize($c['name']) ?>')">Delete</button>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

  </div><!-- /panel-inventory -->

<!-- ════════════════════════════════════
       CUSTOMER ORDERS PANEL
  ═══════════════════════════════════════ -->
  <div id="panel-orders" class="pos-panel" style="display:none;overflow-y:auto;background:#f0f2f5;padding:22px">
    <div class="pg-hdr">
      <div><h2>Customer Orders</h2><p>Manage customer order statuses and details.</p></div>
    </div>
    <div class="panel">
      <div class="ptitle">
        Orders
        <div class="srch-bar">
          <i class="bi bi-search"></i>
          <input type="text" id="order-search" placeholder="Search order ID or customer…" oninput="filterOrderTable()">
        </div>
      </div>
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead><tr><th>Order #</th><th>Date</th><th>Customer</th><th>Contact</th><th>Products</th><th>Qty</th><th>Method</th><th>Total</th><th>Status</th><th>Action</th></tr></thead>
          <tbody id="order-tbody">
            <tr><td colspan="10" class="text-center py-4 text-muted">Loading…</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div><!-- /panel-orders -->

  <!-- ════════════════════════════════════
       TRANSACTION HISTORY PANEL
  ═══════════════════════════════════════ -->
  <div id="panel-history" class="pos-panel" style="display:none;overflow-y:auto;background:#f0f2f5;padding:22px">
    <div class="pg-hdr">
      <div><h2>Transaction History</h2><p>All completed sales</p></div>
      <div class="ftabs" id="hist-tabs">
        <button class="ftab on" data-filter="all"   onclick="setHistFilter('all',this)">All</button>
        <button class="ftab"    data-filter="today" onclick="setHistFilter('today',this)">Today</button>
        <button class="ftab"    data-filter="week"  onclick="setHistFilter('week',this)">7 Days</button>
        <button class="ftab"    data-filter="month" onclick="setHistFilter('month',this)">30 Days</button>
      </div>
    </div>

    <!-- Summary row -->
    <div class="row g-3 mb-3" id="hist-summary">
      <div class="col-md-3"><div class="s-card">
        <div class="s-ico" style="background:rgba(232,119,34,.1);color:var(--orange)"><i class="bi bi-receipt"></i></div>
        <div class="s-val" id="hs-count">—</div><div class="s-lbl">Transactions</div>
      </div></div>
      <div class="col-md-3"><div class="s-card">
        <div class="s-ico" style="background:rgba(6,214,160,.1);color:#059669"><i class="bi bi-currency-dollar"></i></div>
        <div class="s-val" id="hs-revenue">—</div><div class="s-lbl">Total Revenue</div>
      </div></div>
      <div class="col-md-3"><div class="s-card">
        <div class="s-ico" style="background:rgba(78,154,241,.1);color:#2563eb"><i class="bi bi-cash-stack"></i></div>
        <div class="s-val" id="hs-cash">—</div><div class="s-lbl">Cash Sales</div>
      </div></div>
      <div class="col-md-3"><div class="s-card">
        <div class="s-ico" style="background:rgba(124,58,237,.1);color:#7c3aed"><i class="bi bi-phone-fill"></i></div>
        <div class="s-val" id="hs-gcash">—</div><div class="s-lbl">GCash / Card</div>
      </div></div>
    </div>

    <div class="panel">
      <div class="ptitle">Records
        <div class="srch-bar">
          <i class="bi bi-search"></i>
          <input type="text" id="hist-search" placeholder="Search TXN ID…" oninput="filterHistTable()">
        </div>
      </div>
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead><tr><th>TXN ID</th><th>Date & Time</th><th>Cashier</th><th>Items</th><th>Payment</th><th>Total</th><th>Receipt</th></tr></thead>
          <tbody id="hist-tbody">
            <tr><td colspan="7" class="text-center py-4 text-muted">Loading…</td></tr>
          </tbody>
        </table>
      </div>
      <div id="hist-load-more" style="text-align:center;padding:14px;display:none">
        <button class="btn-ed be" onclick="loadHistory(true)">Load More</button>
      </div>
    </div>
  </div><!-- /panel-history -->

  <!-- ════════════════════════════════════
       PROFILE PANEL
  ═══════════════════════════════════════ -->
  <div id="panel-profile" class="pos-panel" style="display:none;overflow-y:auto;background:#f0f2f5;padding:22px">
    <div class="pg-hdr"><div><h2>My Profile</h2><p>Update your account details</p></div></div>

    <div class="row g-3">
      <div class="col-md-6">
        <div class="panel">
          <div class="ptitle">Account Information</div>
          <div id="profile-msg" style="display:none;margin-bottom:12px"></div>
          <form id="profile-form" onsubmit="saveProfile(event)">
            <div class="fg">
              <label class="fg-label">Full Name</label>
              <input class="fc" id="pf-name" value="<?= sanitize($user['name']) ?>" placeholder="Full Name" required>
            </div>
            <div class="fg">
              <label class="fg-label">Username</label>
              <input class="fc" id="pf-username" value="<?= sanitize($_SESSION['user_name'] ?? '') ?>" placeholder="username" required>
            </div>
            <div class="fg">
              <label class="fg-label">Email Address</label>
              <input class="fc" id="pf-email" type="email" value="<?= sanitize($user['email']) ?>" placeholder="email@example.com" required>
            </div>
            <?php
              // Fetch phone from DB for the form
              $phoneStmt = $pdo->prepare('SELECT phone FROM users WHERE id=?');
              $phoneStmt->execute([$user['id']]);
              $phoneRow = $phoneStmt->fetch();
            ?>
            <div class="fg">
              <label class="fg-label">Phone</label>
              <input class="fc" id="pf-phone" value="<?= sanitize($phoneRow['phone'] ?? '') ?>" placeholder="+63 9xx xxx xxxx">
            </div>
            <hr style="margin:16px 0">
            <div class="ptitle" style="margin-bottom:10px;font-size:.85rem">Change Password <small style="color:#aaa;font-weight:400">(leave blank to keep current)</small></div>
            <div class="fg">
              <label class="fg-label">New Password</label>
              <div style="position:relative">
                <input class="fc" id="pf-pw" type="password" placeholder="Min 8 characters" style="padding-right:36px">
                <i class="bi bi-eye" onclick="tpwA('pf-pw',this)"
                   style="position:absolute;right:11px;top:50%;transform:translateY(-50%);cursor:pointer;color:#bbb"></i>
              </div>
            </div>
            <div class="fg">
              <label class="fg-label">Confirm Password</label>
              <input class="fc" id="pf-confirm" type="password" placeholder="Repeat new password">
            </div>
            <button type="submit" class="btn-p mt-1"><i class="bi bi-check-lg"></i> Save Changes</button>
          </form>
        </div>
      </div>

      <div class="col-md-6">
        <div class="panel">
          <div class="ptitle">Account Details</div>
          <div style="display:flex;align-items:center;gap:16px;margin-bottom:18px">
            <div style="width:64px;height:64px;border-radius:50%;
                        background:linear-gradient(135deg,var(--orange),var(--orange-light));
                        display:flex;align-items:center;justify-content:center;
                        color:#fff;font-weight:800;font-size:1.6rem;flex-shrink:0">
              <?= strtoupper(substr($user['name'], 0, 1)) ?>
            </div>
            <div>
              <div style="font-size:1.1rem;font-weight:800;color:#1a1a2e" id="pf-display-name"><?= sanitize($user['name']) ?></div>
              <div><span class="bdg <?= $user['role']==='admin'?'bdg-a':($user['role']==='manager'?'bdg-m':'bdg-c') ?>"><?= ucfirst($user['role']) ?></span></div>
              <div style="font-size:.75rem;color:#aaa;margin-top:4px"><?= sanitize($user['email']) ?></div>
            </div>
          </div>
          <?php
            $myStats = $pdo->prepare("SELECT COUNT(*) as total, COALESCE(SUM(total_amount),0) as revenue FROM transactions WHERE cashier_id=? AND status='completed'");
            $myStats->execute([$user['id']]);
            $ms = $myStats->fetch();
          ?>
          <div style="background:#f8f9fa;border-radius:11px;padding:14px">
            <div class="tot-row" style="margin-bottom:8px">
              <span style="font-size:.78rem;color:#888">My Transactions</span>
              <strong><?= (int)$ms['total'] ?></strong>
            </div>
            <div class="tot-row">
              <span style="font-size:.78rem;color:#888">My Revenue</span>
              <strong style="color:var(--orange)"><?= $currency ?><?= number_format($ms['revenue'], 2) ?></strong>
            </div>
          </div>
        </div>

        <?php if ($isAdmin): ?>
        <!-- Admin-only: System Settings -->
        <div class="panel mt-3">
          <div class="ptitle">System Settings</div>
          <div id="settings-msg" style="display:none;margin-bottom:10px"></div>
          <form id="settings-form" onsubmit="saveSettings(event)">
            <div class="fg">
              <label class="fg-label">Cafe Name</label>
              <input class="fc" id="s-name" value="<?= sanitize($cafeName) ?>">
            </div>
            <div class="fg">
              <label class="fg-label">Address</label>
              <input class="fc" id="s-addr" value="<?= sanitize($cafeAddr) ?>">
            </div>
            <div class="fg">
              <label class="fg-label">Phone</label>
              <input class="fc" id="s-phone" value="<?= sanitize($cafePhone) ?>">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <div class="fg">
                <label class="fg-label">Tax Rate (%)</label>
                <input class="fc" id="s-tax" type="number" step="0.1" min="0" max="100" value="<?= sanitize(getSetting('tax_rate','10')) ?>">
              </div>
              <div class="fg">
                <label class="fg-label">Currency Symbol</label>
                <input class="fc" id="s-cur" value="<?= sanitize($currency) ?>" maxlength="3">
              </div>
            </div>
            <div class="fg">
              <label class="fg-label">Shipping Fee</label>
              <input class="fc" id="s-shipping" type="number" step="0.01" min="0" value="<?= sanitize(getSetting('shipping_fee','50.00')) ?>">
            </div>
            <button type="submit" class="btn-p mt-1"><i class="bi bi-check-lg"></i> Save Settings</button>
          </form>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Admin user management -->
    <?php if ($isAdmin): ?>
    <div class="panel mt-3">
      <div class="ptitle">
        User Accounts
        <button class="btn-p" onclick="openUserModal()"><i class="bi bi-person-plus-fill"></i> Add User</button>
      </div>
      <div style="overflow-x:auto">
        <table class="tbl">
          <thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Email</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
          <?php
          $allUsers = $pdo->query("SELECT * FROM users ORDER BY role, name")->fetchAll();
          foreach ($allUsers as $u):
          ?>
          <tr>
            <td style="font-weight:600">
              <div style="display:flex;align-items:center;gap:8px">
                <div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,var(--orange),var(--orange-light));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.75rem;flex-shrink:0">
                  <?= strtoupper(substr($u['name'], 0, 1)) ?>
                </div>
                <?= sanitize($u['name']) ?>
              </div>
            </td>
            <td><code style="font-size:.78rem"><?= sanitize($u['username']) ?></code></td>
            <td><span class="bdg <?= $u['role']==='admin'?'bdg-a':($u['role']==='manager'?'bdg-m':'bdg-c') ?>"><?= ucfirst($u['role']) ?></span></td>
            <td style="font-size:.78rem"><?= sanitize($u['email']) ?></td>
            <td><span class="dot <?= $u['status']==='active'?'dot-on':'dot-off' ?>"></span><?= ucfirst($u['status']) ?></td>
            <td style="font-size:.75rem;color:#aaa"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
            <td>
              <button class="btn-ed be" onclick='openUserModal(<?= json_encode($u) ?>)'>Edit</button>
              <button class="btn-ed" style="background:rgba(255,209,102,.18);color:#b45309;margin-left:4px"
                      onclick="resetPwModal(<?= $u['id'] ?>,'<?= sanitize($u['name']) ?>')">
                <i class="bi bi-key-fill"></i>
              </button>
              <button class="btn-ed ms-1 <?= $u['status']==='active'?'bd':'be' ?>"
                      onclick="toggleStatus(<?= $u['id'] ?>,'<?= $u['status']==='active'?'inactive':'active' ?>')">
                <i class="bi bi-<?= $u['status']==='active'?'slash-circle':'check-circle' ?>"></i>
              </button>
            </td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </div><!-- /panel-profile -->

</div><!-- /panel-wrap -->

<!-- ════ TOAST ════ -->
<div id="toast-wrap"></div>

<!-- ════════════════════════════════════════════════
     MODALS
═══════════════════════════════════════════════════ -->

<!-- Modal: Payment -->
<div class="mo" id="mo-pay">
  <div class="mb">
    <div class="mh"><h3>Complete Payment</h3><button class="mc" onclick="closeMo('mo-pay')">✕</button></div>
    <!-- Amount due display -->
    <div style="background:#f8f9fa;border-radius:11px;padding:14px;display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
      <span style="font-size:.82rem;color:#777">Amount Due</span>
      <span id="pay-due" style="font-size:1.45rem;font-weight:800;color:var(--orange)"><?= $currency ?>0.00</span>
    </div>
    <!-- Payment method selector -->
    <div class="pm-meth">
      <div class="pm-m on" onclick="setPayMethod('cash',this)"><i class="bi bi-cash-stack"></i>Cash</div>
      <div class="pm-m"    onclick="setPayMethod('card',this)"><i class="bi bi-credit-card-fill"></i>Card</div>
      <div class="pm-m"    onclick="setPayMethod('gcash',this)"><i class="bi bi-phone-fill"></i>GCash</div>
    </div>
    <!-- Cash section -->
    <div id="sec-cash">
      <div class="fg" style="margin-bottom:8px">
        <label style="font-size:.78rem;font-weight:600;color:#666;display:block;margin-bottom:4px">Cash Received</label>
        <input class="fc" id="cash-in" type="number" step="0.01" min="0" placeholder="0.00" oninput="calcChange()">
      </div>
      <div class="chng-box">
        <div class="chng-lbl">Change</div>
        <div class="chng-val" id="chng-val"><?= $currency ?>0.00</div>
      </div>
      <!-- Quick-cash buttons -->
      <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:8px" id="quick-cash"></div>
    </div>
    <!-- Card section -->
    <div id="sec-card" style="display:none">
      <div class="fg">
        <label style="font-size:.78rem;font-weight:600;color:#666;display:block;margin-bottom:4px">Card / Reference No.</label>
        <input class="fc" id="card-ref" placeholder="1234-5678-xxxx">
      </div>
    </div>
    <!-- GCash section -->
    <div id="sec-gcash" style="display:none">
      <div style="background:#f0f4ff;border-radius:11px;padding:14px;text-align:center;color:#2563eb">
        <i class="bi bi-qr-code" style="font-size:2.8rem;display:block;margin-bottom:5px"></i>
        <div style="font-size:.78rem;font-weight:600">Scan GCash QR to pay</div>
        <input class="fc" id="gcash-ref" placeholder="GCash Reference No." style="margin-top:8px;color:#333">
      </div>
    </div>
    <button class="btn-pay" onclick="confirmPayment()" style="margin-top:14px;border-radius:11px">
      <i class="bi bi-check-circle-fill"></i> Confirm Payment
    </button>
  </div>
</div>

<!-- Modal: Receipt -->
<div class="mo" id="mo-rcp">
  <div class="mb" style="max-width:400px">
    <div class="mh"><h3>Receipt</h3><button class="mc" onclick="closeMo('mo-rcp');newOrder()">✕</button></div>
    <div class="rcp" id="rcp-body"></div>
    <div style="display:flex;gap:9px;margin-top:14px">
      <button class="btn-p" style="flex:1;justify-content:center" onclick="printReceipt()">
        <i class="bi bi-printer"></i> Print
      </button>
      <button class="btn-ed be" style="flex:1;padding:8px;font-size:.8rem;text-align:center" onclick="closeMo('mo-rcp');newOrder()">
        <i class="bi bi-plus-circle"></i> New Order
      </button>
    </div>
  </div>
</div>

<!-- Modal: View Transaction Receipt (from history) -->
<div class="mo" id="mo-txn-view">
  <div class="mb" style="max-width:440px">
    <div class="mh"><h3>Transaction Detail</h3><button class="mc" onclick="closeMo('mo-txn-view')">✕</button></div>
    <div class="rcp" id="txn-view-body"></div>
    <div style="margin-top:14px;display:flex;gap:8px">
      <button class="btn-p" style="flex:1;justify-content:center" onclick="printTxnView()">
        <i class="bi bi-printer"></i> Print Receipt
      </button>
      <button class="btn-ed be" style="flex:1;text-align:center" onclick="closeMo('mo-txn-view')">Close</button>
    </div>
  </div>
</div>

<!-- Modal: Add/Edit Product -->
<div class="mo" id="mo-prod">
  <div class="mb">
    <div class="mh"><h3 id="mo-prod-t">Add Product</h3><button class="mc" onclick="closeMo('mo-prod')">✕</button></div>
    <form onsubmit="saveProd(event)">
      <input type="hidden" id="p-id">
      <div class="f2">
        <div class="fg"><label>Product Name *</label><input class="fc" id="p-name" placeholder="e.g. Espresso" required></div>
        <div class="fg"><label>Icon (emoji)</label><input class="fc" id="p-icon" placeholder="☕" maxlength="4"></div>
      </div>
      <div class="f2">
        <div class="fg">
          <label>Category *</label>
          <select class="fc" id="p-cat">
            <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="fg"><label>Price (<?= $currency ?>) *</label><input class="fc" id="p-price" type="number" step="0.01" min="0.01" placeholder="0.00" required></div>
      </div>
      <div class="f2">
        <div class="fg"><label>Stock Quantity *</label><input class="fc" id="p-stock" type="number" min="0" placeholder="0" required></div>
        <div class="fg"><label>Status</label>
          <select class="fc" id="p-active">
            <option value="1">Active</option>
            <option value="0">Hidden</option>
          </select>
        </div>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
        <button type="button" class="btn-ed be" style="padding:8px 16px" onclick="closeMo('mo-prod')">Cancel</button>
        <button type="submit" class="btn-p"><i class="bi bi-check-lg"></i> Save Product</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Add/Edit Category -->
<div class="mo" id="mo-cat">
  <div class="mb" style="max-width:400px">
    <div class="mh"><h3 id="mo-cat-t">Add Category</h3><button class="mc" onclick="closeMo('mo-cat')">✕</button></div>
    <form onsubmit="saveCat(event)">
      <input type="hidden" id="cat-id">
      <div class="f2">
        <div class="fg"><label>Name *</label><input class="fc" id="cat-name" placeholder="e.g. Desserts" required></div>
        <div class="fg"><label>Icon (emoji)</label><input class="fc" id="cat-icon" placeholder="🍰" maxlength="4"></div>
      </div>
      <div class="fg"><label>Sort Order</label><input class="fc" id="cat-sort" type="number" min="0" placeholder="0"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
        <button type="button" class="btn-ed be" style="padding:8px 16px" onclick="closeMo('mo-cat')">Cancel</button>
        <button type="submit" class="btn-p"><i class="bi bi-check-lg"></i> Save Category</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Add/Edit User (admin) -->
<div class="mo" id="mo-user">
  <div class="mb" style="max-width:500px">
    <div class="mh"><h3 id="mo-user-t">Add User</h3><button class="mc" onclick="closeMo('mo-user')">✕</button></div>
    <form onsubmit="saveUser(event)">
      <input type="hidden" id="u-id">
      <div class="f2">
        <div class="fg"><label>Full Name *</label><input class="fc" id="u-name" placeholder="Juan dela Cruz" required></div>
        <div class="fg"><label>Username *</label><input class="fc" id="u-username" placeholder="juandc" required></div>
      </div>
      <div class="fg"><label>Email *</label><input class="fc" id="u-email" type="email" placeholder="juan@simbacafe.com" required></div>
      <div class="fg"><label>Phone</label><input class="fc" id="u-phone" placeholder="+63 9xx xxx xxxx"></div>
      <div class="f2">
        <div class="fg"><label>Role</label>
          <select class="fc" id="u-role">
            <option value="admin">Admin</option>
            <option value="manager">Manager</option>
            <option value="cashier" selected>Cashier</option>
          </select>
        </div>
        <div class="fg"><label>Status</label>
          <select class="fc" id="u-status">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="fg">
        <label>Password <small id="u-pw-hint" class="text-muted">(required for new users)</small></label>
        <div style="position:relative">
          <input class="fc" id="u-pw" type="password" placeholder="Min 8 characters" style="padding-right:36px">
          <i class="bi bi-eye" onclick="tpwA('u-pw',this)"
             style="position:absolute;right:11px;top:50%;transform:translateY(-50%);cursor:pointer;color:#bbb"></i>
        </div>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
        <button type="button" class="btn-ed be" style="padding:8px 16px" onclick="closeMo('mo-user')">Cancel</button>
        <button type="submit" class="btn-p"><i class="bi bi-check-lg"></i> Save User</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Reset Password (admin) -->
<div class="mo" id="mo-reset-pw">
  <div class="mb" style="max-width:400px">
    <div class="mh"><h3>Reset Password</h3><button class="mc" onclick="closeMo('mo-reset-pw')">✕</button></div>
    <p id="reset-pw-name" style="font-size:.84rem;color:#666;margin-bottom:14px"></p>
    <input type="hidden" id="reset-uid">
    <div class="fg"><label>New Password</label><input class="fc" id="reset-pw1" type="password" placeholder="Min 8 characters" required></div>
    <div class="fg"><label>Confirm Password</label><input class="fc" id="reset-pw2" type="password" placeholder="Repeat password" required></div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
      <button class="btn-ed be" style="padding:8px 16px" onclick="closeMo('mo-reset-pw')">Cancel</button>
      <button class="btn-p" onclick="doResetPw()"><i class="bi bi-key-fill"></i> Reset Password</button>
    </div>
  </div>
</div>

<!-- Inject PHP data for JS -->
<script>
// Data passed from PHP to JavaScript
const PRODUCTS  = <?= json_encode(array_values($products)) ?>;
const CATEGORIES = <?= json_encode(array_values($categories)) ?>;
const TAX_RATE  = <?= $taxRate ?>;
const CURRENCY  = <?= json_encode($currency) ?>;
const CASHIER   = <?= json_encode($user['name']) ?>;
const CAFE_NAME = <?= json_encode($cafeName) ?>;
const CAFE_ADDR = <?= json_encode($cafeAddr) ?>;
const CAFE_PHONE = <?= json_encode($cafePhone) ?>;
const IS_ADMIN  = <?= $isAdmin ? 'true' : 'false' ?>;
// API endpoint for AJAX calls from this admin page
const API_URL = '../api.php';
</script>
<script>
<?php echo str_replace('</script>', '<\/script>', file_get_contents(__DIR__ . '/../assets/js/cashier.js')); ?>
</script>
</body>
</html>