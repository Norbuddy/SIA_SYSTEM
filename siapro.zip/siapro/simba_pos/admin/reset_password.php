<?php
// ============================================================
// reset_password.php — Set a new password via token
// ============================================================
require_once __DIR__ . '/../config.php';

if (isLoggedIn()) { header('Location: cashier_dashboard.php'); exit; }

$token  = trim($_GET['token'] ?? '');
$err    = $msg = '';
$valid  = false;
$userId = null;

// Validate token
if ($token) {
    $stmt = db()->prepare("SELECT id FROM users WHERE reset_token=? AND reset_exp > NOW() AND status='active'");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if ($user) {
        $valid  = true;
        $userId = $user['id'];
    } else {
        $err = 'This reset link is invalid or has expired. Please request a new one.';
    }
}

// Handle password update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $valid) {
    $pw1 = $_POST['pw1'] ?? '';
    $pw2 = $_POST['pw2'] ?? '';
    if (strlen($pw1) < 8) {
        $err = 'Password must be at least 8 characters.';
    } elseif ($pw1 !== $pw2) {
        $err = 'Passwords do not match.';
    } else {
        $hash = password_hash($pw1, PASSWORD_BCRYPT);
        $upd  = db()->prepare('UPDATE users SET password=?, reset_token=NULL, reset_exp=NULL, updated_at=NOW() WHERE id=?');
        $upd->execute([$hash, $userId]);
        $msg   = 'Password updated successfully! You can now sign in.';
        $valid = false; // Hide the form after success
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset Password — Simba Cafe POS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="../style.css">
</head>
<body class="auth-page">
<div class="auth-bg">
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>

  <div class="auth-card">
    <div class="a-logo">
      <div class="a-ico"><i class="bi bi-cup-hot-fill"></i></div>
      <div><h1>Simba Cafe</h1><span>Set New Password</span></div>
    </div>
    <h2 class="a-title">Reset Password</h2>

    <?php if ($err): ?>
    <div class="alert-box err mb-3"><i class="bi bi-exclamation-circle-fill"></i> <?= sanitize($err) ?></div>
    <?php endif; ?>
    <?php if ($msg): ?>
    <div class="alert-box ok mb-3"><i class="bi bi-check-circle-fill"></i> <?= sanitize($msg) ?></div>
    <a href="index.php" class="btn-a" style="display:flex;margin-top:12px">
      <i class="bi bi-box-arrow-in-right"></i> Go to Login
    </a>
    <?php elseif ($valid): ?>
    <form method="POST">
      <div class="fg">
        <label class="a-lbl">New Password</label>
        <div class="a-inp-wrap">
          <input class="a-inp" type="password" name="pw1" id="pw1" placeholder="Min 8 characters" required>
          <i class="bi bi-eye eye" onclick="tpw('pw1',this)"></i>
        </div>
      </div>
      <div class="fg">
        <label class="a-lbl">Confirm New Password</label>
        <div class="a-inp-wrap">
          <input class="a-inp" type="password" name="pw2" id="pw2" placeholder="Repeat password" required>
          <i class="bi bi-eye eye" onclick="tpw('pw2',this)"></i>
        </div>
      </div>
      <button type="submit" class="btn-a mt-2">
        <i class="bi bi-shield-check"></i> Set New Password
      </button>
    </form>
    <?php elseif (!$msg): ?>
    <div class="alert-box err"><i class="bi bi-x-circle-fill"></i> No valid token provided.</div>
    <a class="a-lnk d-block text-center mt-3" href="forgot_password.php">
      <i class="bi bi-arrow-left"></i> Request a new reset link
    </a>
    <?php endif; ?>
  </div>
</div>
<script>
function tpw(id, el) {
  const i = document.getElementById(id);
  i.type = i.type === 'password' ? 'text' : 'password';
  el.className = 'eye bi bi-' + (i.type === 'password' ? 'eye' : 'eye-slash');
}
</script>
</body>
</html>