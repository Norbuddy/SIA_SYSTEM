<?php
// ============================================================
// config.php — Database connection & application config
// ============================================================

// Database configuration — prefer environment variables for local/docker runs
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: 'simba_pos');

define('APP_NAME',    'Simba Cafe POS');
define('APP_VERSION', '2.0');
define('TAX_RATE',    0.10);         // 10% — overridden by DB setting

// Session lifetime: 8 hours
define('SESSION_LIFETIME', 3600 * 8);

// Start session once, with secure settings
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// Restrict to localhost access when running under a web server.
if (PHP_SAPI !== 'cli') {
    $host = $_SERVER['HTTP_HOST'] ?? '';
    // strip port if present
    $hostOnly = preg_replace('/:.+$/', '', $host);
    $allowed = ['localhost', '127.0.0.1', '::1'];
    if (!in_array($hostOnly, $allowed, true)) {
        http_response_code(403);
        echo 'Access denied. This application is restricted to localhost.';
        exit;
    }
}

// ──────────────────────────────────────────
// Database connection (PDO singleton)
// ──────────────────────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ──────────────────────────────────────────
// Auth helpers
// ──────────────────────────────────────────
function isLoggedIn(): bool {
    return !empty($_SESSION['user_role']) && in_array(getUserRole(), ['admin','manager','cashier','customer'], true)
        && (
            !empty($_SESSION['user_id'])
            || !empty($_SESSION['admin_id'])
            || !empty($_SESSION['manager_id'])
            || !empty($_SESSION['customer_id'])
        );
}

/**
 * Convenience role checks for all account types
 */
function getUserRole(): string {
    return strtolower(trim((string)($_SESSION['user_role'] ?? '')));
}

function isAdmin(): bool {
    return getUserRole() === 'admin' && !empty($_SESSION['admin_id']);
}

function isManager(): bool {
    return getUserRole() === 'manager' && !empty($_SESSION['manager_id']);
}

function isCashier(): bool {
    return getUserRole() === 'cashier' && !empty($_SESSION['cashier_id']);
}

function isCustomer(): bool {
    return getUserRole() === 'customer' && !empty($_SESSION['customer_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function requireStaff(): void {
    requireLogin();
    if (!isAdmin() && !isCashier()) {
        header('Location: index.php');
        exit;
    }
}

function requireCashier(): void {
    requireLogin();
    if (!isCashier()) {
        header('Location: index.php');
        exit;
    }
}

function requireManager(): void {
    requireLogin();
    if (!isManager()) {
        header('Location: index.php');
        exit;
    }
}

function requireCustomer(): void {
    requireLogin();
    if (!isCustomer()) {
        header('Location: index.php');
        exit;
    }
}


function redirectToDashboard(): void {
    if (isAdmin() || isCashier()) {
        header('Location: admin/cashier_dashboard.php');
        exit;
    }
    if (isManager()) {
        header('Location: manager_dashboard.php');
        exit;
    }
    if (isCustomer()) {
        header('Location: customers/customer_dashboard.php');
        exit;
    }
    header('Location: index.php');
    exit;
}

function isAjaxRequest(): bool {
    $requestedWith = strtolower(trim((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')));
    $acceptHeader  = strtolower(trim((string)($_SERVER['HTTP_ACCEPT'] ?? '')));

    return $requestedWith === 'xmlhttprequest'
        || str_contains($acceptHeader, 'application/json')
        || preg_match('/\bjson\b/i', $acceptHeader);
}

function requireAdmin(): void {
    requireLogin();
    if (!isAdmin() && !isManager()) {
        if (isAjaxRequest()) {
            jsonResponse(['success' => false, 'message' => 'Access denied.'], 403);
        }
        if (isLoggedIn()) {
            header('Location: cashier_dashboard.php');
        } else {
            header('Location: index.php');
        }
        exit;
    }
}

function currentUser(): array {
    return [
        'id'    => $_SESSION['user_id']   ?? null,
        'name'  => $_SESSION['user_name'] ?? 'User',
        'role'  => $_SESSION['user_role'] ?? 'cashier',
        'email' => $_SESSION['user_email'] ?? '',
    ];
}

// ──────────────────────────────────────────
// Utility helpers
// ──────────────────────────────────────────

/**
 * Fetch a setting from the DB with an in-request cache.
 */
function getSetting(string $key, string $default = ''): string {
    static $cache = [];
    if (!array_key_exists($key, $cache)) {
        try {
            $stmt = db()->prepare('SELECT `value` FROM settings WHERE `key` = ?');
            $stmt->execute([$key]);
            $row = $stmt->fetch();
            $cache[$key] = $row ? $row['value'] : $default;
        } catch (Exception $e) {
            $cache[$key] = $default;
        }
    }
    return $cache[$key];
}

/**
 * Send a JSON response and exit.
 */
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function tableExists(string $table): bool {
    $stmt = db()->prepare(
        'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1'
    );
    $stmt->execute([$table]);
    return (bool)$stmt->fetchColumn();
}

function ensureAdminsTable(): void {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        username VARCHAR(100) NOT NULL UNIQUE,
        email VARCHAR(150) NOT NULL UNIQUE,
        phone VARCHAR(30) DEFAULT '',
        password VARCHAR(255) NOT NULL,
        role ENUM('admin','cashier') NOT NULL DEFAULT 'cashier',
        status ENUM('active','inactive') NOT NULL DEFAULT 'active',
        reset_token VARCHAR(128) DEFAULT NULL,
        reset_exp DATETIME DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (tableExists('users')) {
        $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('admin','manager','cashier')")->fetchColumn();
        if ($count > 0) {
            $migrated = (int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
            if ($migrated === 0) {
                $pdo->exec("INSERT IGNORE INTO admins (id,name,username,email,phone,password,role,status,created_at,updated_at)
                    SELECT id,name,username,email,phone,password,role,status,created_at,updated_at FROM users WHERE role IN ('admin','cashier')");
            }
        }
    }
}

function ensureManagersTable(): void {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS managers (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        username VARCHAR(100) NOT NULL UNIQUE,
        email VARCHAR(150) NOT NULL UNIQUE,
        phone VARCHAR(30) DEFAULT '',
        password VARCHAR(255) NOT NULL,
        status ENUM('active','inactive') NOT NULL DEFAULT 'active',
        reset_token VARCHAR(128) DEFAULT NULL,
        reset_exp DATETIME DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    if (tableExists('users')) {
        $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'manager'")->fetchColumn();
        if ($count > 0) {
            $migrated = (int)$pdo->query("SELECT COUNT(*) FROM managers")->fetchColumn();
            if ($migrated === 0) {
                $pdo->exec("INSERT IGNORE INTO managers (id,name,username,email,phone,password,status,created_at,updated_at)
                    SELECT id,name,username,email,phone,password,status,created_at,updated_at FROM users WHERE role = 'manager'");
            }
        }
    }
}

function ensureCustomersTable(): void {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS customers (
        id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        username VARCHAR(100) NOT NULL UNIQUE,
        phone VARCHAR(30) DEFAULT '',
        password VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/**
 * XSS-safe output helper.
 */
function sanitize(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate the next transaction code (e.g. TXN-0042).
 * Uses a DB-level count so concurrent requests stay consistent.
 */
function nextTxnCode(): string {
    $stmt = db()->query('SELECT COUNT(*) as cnt FROM transactions');
    $row  = $stmt->fetch();
    return 'TXN-' . str_pad((int)$row['cnt'] + 1, 4, '0', STR_PAD_LEFT);
}