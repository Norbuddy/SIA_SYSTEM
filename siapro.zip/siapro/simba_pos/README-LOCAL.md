Local run (XAMPP / phpMyAdmin or PHP built-in server)

This project is intended to run on `localhost` only. You can run it using XAMPP/phpMyAdmin or PHP's built-in server.

XAMPP / phpMyAdmin (recommended for Windows)
1. Place this project in XAMPP's `htdocs` (e.g. `C:\xampp\htdocs\simba_pos`).
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open phpMyAdmin at http://localhost/phpmyadmin and import `simba_pos_full.sql` from the project root to create the database and sample data.
4. Ensure `config.php` DB settings match your MySQL credentials (default XAMPP MySQL: user `root`, empty password).
5. Open the app at: http://localhost/simba_pos/

PHP built-in server (quick dev)
- Import the SQL using phpMyAdmin or another MySQL client first.
- From the project root run:

```powershell
php -S localhost:8000
```

Then open http://localhost:8000

Local-only enforcement
- The app enforces a localhost-only policy; requests must use a `Host` header of `localhost`, `127.0.0.1`, or `::1`.

If you want Docker instead, tell me and I can re-add the `docker-compose.yml` and init scripts.
