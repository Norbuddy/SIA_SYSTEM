<?php
require 'config.php';

$icons = [
    1  => '🍔',
    2  => '🍔',
    3  => '🍕',
    4  => '🍗',
    5  => '🍟',
    6  => '🍗',
    7  => '🍸',
    8  => '🥃',
    9  => '🍷',
    10 => '🥃',
    11 => '🥤',
    12 => '🥤',
    13 => '🥤',
    14 => '🥤',
    15 => '🥤',
    16 => '🥤',
    17 => '🥤',
    18 => '🥤',
    19 => '🍊',
    20 => '💧',
    21 => '🍰',
    22 => '🍨'
];

$stmt = db()->prepare("UPDATE products SET icon = ? WHERE id = ?");

foreach ($icons as $id => $icon) {
    $stmt->execute([$icon, $id]);
}

echo "✅ All product icons have been updated successfully!";

$icons = [
    1 => '🍔', // Food
    2 => '🍷', // Alcohol
    3 => '🥤', // Cold Drinks
    4 => '☕', // Hot Drinks
    5 => '🍰'  // Desserts
];

$stmt = db()->prepare("UPDATE categories SET icon = ? WHERE id = ?");

foreach ($icons as $id => $icon) {
    $stmt->execute([$icon, $id]);
}

echo "✅ Category icons updated successfully!";

$sql = "
UPDATE transaction_items ti
JOIN products p ON ti.product_id = p.id
SET ti.product_icon = p.icon
";

db()->exec($sql);

echo "✅ Transaction icons updated successfully!";