<?php
// ============================================================
// index.php — Login page + register (entry point)
// ============================================================
require_once __DIR__ . '/config.php';

// Already logged in → redirect to appropriate dashboard
if (isLoggedIn()) {
    $role = $_SESSION['user_role'];
    header('Location: ' . (in_array($role, ['admin','manager']) ? 'cashier_dashboard.php' : 'cashier_dashboard.php'));
    exit;
}

$error   = '';
$success = '';
$mode    = $_GET['mode'] ?? 'login'; // 'login' | 'register'

// ── Handle Login ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$username || !$password) {
        $error = 'Username and password are required.';
    } else {
        // Allow login by username OR email
        $stmt = db()->prepare("
            SELECT * FROM users
            WHERE (username = ? OR email = ?) AND status = 'active'
            LIMIT 1
        ");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Regenerate session ID to prevent fixation attacks
            session_regenerate_id(true);
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['user_name']  = $user['name'];
            $_SESSION['user_role']  = $user['role'];
            $_SESSION['user_email'] = $user['email'];

            // All roles go to the cashier/POS dashboard
            header('Location: cashier_dashboard.php');
            exit;
        } else {
            $error = 'Invalid credentials or account is inactive.';
        }
    }
    $mode = 'login';
}

// ── Handle Register ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'register') {
    $mode     = 'register';
    $name     = trim($_POST['reg_name']     ?? '');
    $username = strtolower(trim($_POST['reg_username'] ?? ''));
    $email    = strtolower(trim($_POST['reg_email']    ?? ''));
    $phone    = trim($_POST['reg_phone']    ?? '');
    $password = $_POST['reg_password']      ?? '';
    $confirm  = $_POST['reg_confirm']       ?? '';

    // Validation
    if (!$name || !$username || !$email || !$password) {
        $error = 'All required fields must be filled in.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (!preg_match('/^[a-z0-9_]{3,30}$/', $username)) {
        $error = 'Username must be 3–30 characters: letters, numbers, underscores only.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // Check uniqueness
        $chk = db()->prepare('SELECT id FROM users WHERE username=? OR email=?');
        $chk->execute([$username, $email]);
        if ($chk->fetch()) {
            $error = 'Username or email is already taken.';
        } else {
            // Insert as cashier by default — admin can promote later
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = db()->prepare('INSERT INTO users (name, username, email, phone, password, role, status) VALUES (?,?,?,?,?,?,?)');
            $stmt->execute([$name, $username, $email, $phone, $hash, 'cashier', 'active']);

            // Auto-login after registration
            $userId = db()->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['user_id']    = $userId;
            $_SESSION['user_name']  = $name;
            $_SESSION['user_role']  = 'cashier';
            $_SESSION['user_email'] = $email;

            header('Location: cashier_dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $mode === 'register' ? 'Create Account' : 'Login' ?> — Simba Cafe POS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-page">

<div class="auth-bg">
  <!-- Decorative blobs -->
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>

  <div class="auth-card" style="max-width: <?= $mode === 'register' ? '480px' : '420px' ?>">
    <!-- Logo -->
    <div class="a-logo">
      <div class="a-ico"><i class="bi bi-cup-hot-fill"></i></div>
      <div>
        <h1>Simba Cafe</h1>
        <span><?= $mode === 'register' ? 'Create Account' : 'Point of Sale System' ?></span>
      </div>
    </div>

    <!-- Error / Success -->
    <?php if ($error): ?>
    <div class="alert-box err mb-3">
      <i class="bi bi-exclamation-circle-fill"></i> <?= sanitize($error) ?>
    </div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert-box ok mb-3">
      <i class="bi bi-check-circle-fill"></i> <?= sanitize($success) ?>
    </div>
    <?php endif; ?>

    <?php if ($mode === 'register'): ?>
    <!-- ════ REGISTER FORM ════ -->
    <h2 class="a-title">Create your account</h2>
    <p class="a-sub">New accounts are created as Cashier role. An admin can promote you later.</p>

    <form method="POST" action="index.php?mode=register" autocomplete="off">
      <input type="hidden" name="action" value="register">
      <div class="fg">
        <label class="a-lbl">Full Name <span style="color:#ef476f">*</span></label>
        <input class="a-inp" type="text" name="reg_name"
               value="<?= sanitize($_POST['reg_name'] ?? '') ?>" placeholder="Juan dela Cruz" required>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg">
          <label class="a-lbl">Username <span style="color:#ef476f">*</span></label>
          <input class="a-inp" type="text" name="reg_username"
                 value="<?= sanitize($_POST['reg_username'] ?? '') ?>" placeholder="juandc" required
                 pattern="[a-zA-Z0-9_]{3,30}" title="3–30 chars, letters/numbers/underscores">
        </div>
        <div class="fg">
          <label class="a-lbl">Phone</label>
          <input class="a-inp" type="text" name="reg_phone"
                 value="<?= sanitize($_POST['reg_phone'] ?? '') ?>" placeholder="+63 9xx xxx xxxx">
        </div>
      </div>
      <div class="fg">
        <label class="a-lbl">Email Address <span style="color:#ef476f">*</span></label>
        <input class="a-inp" type="email" name="reg_email"
               value="<?= sanitize($_POST['reg_email'] ?? '') ?>" placeholder="juan@simbacafe.com" required>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div class="fg">
          <label class="a-lbl">Password <span style="color:#ef476f">*</span></label>
          <div class="a-inp-wrap">
            <input class="a-inp" type="password" name="reg_password" id="r-pw1" placeholder="Min 8 characters" required>
            <i class="bi bi-eye eye" onclick="tpw('r-pw1',this)"></i>
          </div>
        </div>
        <div class="fg">
          <label class="a-lbl">Confirm Password <span style="color:#ef476f">*</span></label>
          <div class="a-inp-wrap">
            <input class="a-inp" type="password" name="reg_confirm" id="r-pw2" placeholder="Repeat password" required>
            <i class="bi bi-eye eye" onclick="tpw('r-pw2',this)"></i>
          </div>
        </div>
      </div>
      <button type="submit" class="btn-a mt-2">
        <i class="bi bi-person-plus-fill"></i> Create Account
      </button>
    </form>
    <div class="text-center mt-3">
      <a class="a-lnk" href="index.php?mode=login">
        <i class="bi bi-arrow-left"></i> Already have an account? Sign in
      </a>
    </div>

    <?php else: ?>
    <!-- ════ LOGIN FORM ════ -->
    <h2 class="a-title">Welcome back</h2>
    <p class="a-sub">Sign in to continue</p>

    <form method="POST" action="index.php?mode=login" autocomplete="off">
      <input type="hidden" name="action" value="login">
      <div class="fg">
        <label class="a-lbl">Username or Email</label>
        <input class="a-inp" type="text" name="username"
               value="<?= sanitize($_POST['username'] ?? '') ?>"
               placeholder="admin / cashier …" required>
      </div>
      <div class="fg">
        <label class="a-lbl">Password</label>
        <div class="a-inp-wrap">
          <input class="a-inp" type="password" name="password" id="l-pw" placeholder="••••••••" required>
          <i class="bi bi-eye eye" onclick="tpw('l-pw',this)"></i>
        </div>
      </div>
      <div style="text-align:right;margin-bottom:18px">
        <a class="a-lnk" href="forgot_password.php">Forgot password?</a>
      </div>
      <button type="submit" class="btn-a">
        <i class="bi bi-box-arrow-in-right"></i> Sign In
      </button>
    </form>

    <div class="text-center mt-3">
      <a class="a-lnk" href="index.php?mode=register">
        <i class="bi bi-person-plus"></i> Don't have an account? Create one
      </a>
    </div>

    <div class="mt-3 text-center" style="font-size:.7rem;color:rgba(255,255,255,.28)">
      Demo credentials &mdash; Username: <code style="color:rgba(255,255,255,.45)">admin</code>
      / Password: <code style="color:rgba(255,255,255,.45)">password</code>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
// Toggle password visibility
function tpw(id, el) {
  const i = document.getElementById(id);
  i.type = i.type === 'password' ? 'text' : 'password';
  el.className = 'eye bi bi-' + (i.type === 'password' ? 'eye' : 'eye-slash');
}
</script>
</body>
</html>