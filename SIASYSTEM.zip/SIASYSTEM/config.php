<?php
// ============================================================
// config.php — Database connection & application config
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');           // Change to your MySQL username
define('DB_PASS', '');               // Change to your MySQL password
define('DB_NAME', 'simba_pos');

define('APP_NAME',    'Simba Cafe POS');
define('APP_VERSION', '2.0');
define('TAX_RATE',    0.10);         // 10% — overridden by DB setting

// Session lifetime: 8 hours
define('SESSION_LIFETIME', 3600 * 8);

// Start session once, with secure settings
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// ──────────────────────────────────────────
// Database connection (PDO singleton)
// ──────────────────────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ──────────────────────────────────────────
// Auth helpers
// ──────────────────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['user_id'], $_SESSION['user_role']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function requireAdmin(): void {
    requireLogin();
    if (!in_array($_SESSION['user_role'], ['admin', 'manager'])) {
        // For API calls return JSON, otherwise redirect
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            jsonResponse(['success' => false, 'message' => 'Access denied.'], 403);
        }
        header('Location: cashier_dashboard.php');
        exit;
    }
}

function currentUser(): array {
    return [
        'id'    => $_SESSION['user_id']   ?? null,
        'name'  => $_SESSION['user_name'] ?? 'User',
        'role'  => $_SESSION['user_role'] ?? 'cashier',
        'email' => $_SESSION['user_email'] ?? '',
    ];
}

// ──────────────────────────────────────────
// Utility helpers
// ──────────────────────────────────────────

/**
 * Fetch a setting from the DB with an in-request cache.
 */
function getSetting(string $key, string $default = ''): string {
    static $cache = [];
    if (!array_key_exists($key, $cache)) {
        try {
            $stmt = db()->prepare('SELECT `value` FROM settings WHERE `key` = ?');
            $stmt->execute([$key]);
            $row = $stmt->fetch();
            $cache[$key] = $row ? $row['value'] : $default;
        } catch (Exception $e) {
            $cache[$key] = $default;
        }
    }
    return $cache[$key];
}

/**
 * Send a JSON response and exit.
 */
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * XSS-safe output helper.
 */
function sanitize(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate the next transaction code (e.g. TXN-0042).
 * Uses a DB-level count so concurrent requests stay consistent.
 */
function nextTxnCode(): string {
    $stmt = db()->query('SELECT COUNT(*) as cnt FROM transactions');
    $row  = $stmt->fetch();
    return 'TXN-' . str_pad((int)$row['cnt'] + 1, 4, '0', STR_PAD_LEFT);
}