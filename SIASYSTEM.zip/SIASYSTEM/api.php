<?php
// ============================================================
// api.php — Single AJAX endpoint for all POST/GET actions
// ============================================================
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');

// All API calls require an active session
if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Unauthorized. Please log in again.'], 401);
}

// Determine action from POST or GET
$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {

        // ── Products ──────────────────────────────────────
        case 'save_product':    saveProduct();    break;
        case 'delete_product':  deleteProduct();  break;
        case 'update_stock':    updateStock();    break;
        case 'get_products':    getProducts();    break;

        // ── Categories ────────────────────────────────────
        case 'save_category':   saveCategory();   break;
        case 'delete_category': deleteCategory(); break;

        // ── Transactions (POS Checkout) ────────────────────
        case 'checkout':        checkout();       break;
        case 'get_txn':         getTxn();         break;
        case 'get_txn_history': getTxnHistory();  break;

        // ── User Accounts ──────────────────────────────────
        case 'save_user':       saveUserAction(); break;
        case 'delete_user':     deleteUser();     break;
        case 'toggle_status':   toggleUserStatus(); break;
        case 'reset_password':  resetPassword();  break;
        case 'update_profile':  updateProfile();  break;

        // ── Settings ──────────────────────────────────────
        case 'save_settings':   saveSettings();   break;
        case 'clear_txns':      clearTxns();      break;

        default:
            jsonResponse(['success' => false, 'message' => 'Unknown action: ' . htmlspecialchars($action)], 400);
    }
} catch (PDOException $e) {
    // Log DB errors server-side but don't expose details to client
    error_log('DB error in api.php: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'A database error occurred. Please try again.'], 500);
} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
}

// ════════════════════════════════════════════════
//  PRODUCTS
// ════════════════════════════════════════════════
function saveProduct(): void {
    requireAdmin();
    $pdo      = db();
    $id       = (int)($_POST['id'] ?? 0);
    $name     = trim($_POST['name'] ?? '');
    $catId    = (int)($_POST['category_id'] ?? 0);
    $price    = (float)($_POST['price'] ?? 0);
    $icon     = trim($_POST['icon'] ?? '') ?: '🍽️';
    $stock    = max(0, (int)($_POST['stock'] ?? 0));
    $isActive = (int)($_POST['is_active'] ?? 1);

    if (!$name)     throw new Exception('Product name is required.');
    if (!$catId)    throw new Exception('Category is required.');
    if ($price <= 0) throw new Exception('Price must be greater than zero.');

    if ($id) {
        $stmt = $pdo->prepare('UPDATE products SET name=?,category_id=?,price=?,icon=?,stock=?,is_active=?,updated_at=NOW() WHERE id=?');
        $stmt->execute([$name, $catId, $price, $icon, $stock, $isActive, $id]);
        jsonResponse(['success' => true, 'message' => "\"$name\" updated."]);
    } else {
        $stmt = $pdo->prepare('INSERT INTO products (name,category_id,price,icon,stock,is_active) VALUES (?,?,?,?,?,?)');
        $stmt->execute([$name, $catId, $price, $icon, $stock, $isActive]);
        jsonResponse(['success' => true, 'message' => "\"$name\" added!", 'id' => $pdo->lastInsertId()]);
    }
}

function deleteProduct(): void {
    requireAdmin();
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) throw new Exception('Missing product ID.');

    // Check if this product has existing sales history
    $used = db()->prepare('SELECT COUNT(*) FROM transaction_items WHERE product_id=?');
    $used->execute([$id]);
    if ((int)$used->fetchColumn() > 0) {
        // Soft-delete: hide but keep history intact
        $stmt = db()->prepare('UPDATE products SET is_active=0, updated_at=NOW() WHERE id=?');
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'Product hidden (has sales history — cannot fully delete).']);
    } else {
        $stmt = db()->prepare('DELETE FROM products WHERE id=?');
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'Product deleted.']);
    }
}

function updateStock(): void {
    requireAdmin();
    $id    = (int)($_POST['id'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    if (!$id)    throw new Exception('Missing product ID.');
    if ($stock < 0) throw new Exception('Stock cannot be negative.');
    $stmt = db()->prepare('UPDATE products SET stock=?, updated_at=NOW() WHERE id=?');
    $stmt->execute([$stock, $id]);
    jsonResponse(['success' => true, 'message' => 'Stock updated.']);
}

function getProducts(): void {
    // Any logged-in user can fetch the product list (needed for POS)
    $rows = db()->query("
        SELECT p.*, c.name as cat_name
        FROM products p JOIN categories c ON p.category_id=c.id
        WHERE p.is_active=1
        ORDER BY c.sort_order, p.name
    ")->fetchAll();
    jsonResponse(['success' => true, 'data' => $rows]);
}

// ════════════════════════════════════════════════
//  CATEGORIES
// ════════════════════════════════════════════════
function saveCategory(): void {
    requireAdmin();
    $pdo  = db();
    $id   = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $icon = trim($_POST['icon'] ?? '') ?: '🍽️';
    $sort = (int)($_POST['sort_order'] ?? 0);

    if (!$name) throw new Exception('Category name is required.');

    if ($id) {
        $stmt = $pdo->prepare('UPDATE categories SET name=?,icon=?,sort_order=? WHERE id=?');
        $stmt->execute([$name, $icon, $sort, $id]);
        jsonResponse(['success' => true, 'message' => "Category \"$name\" updated."]);
    } else {
        $stmt = $pdo->prepare('INSERT INTO categories (name,icon,sort_order) VALUES (?,?,?)');
        $stmt->execute([$name, $icon, $sort]);
        jsonResponse(['success' => true, 'message' => "Category \"$name\" added!", 'id' => $pdo->lastInsertId()]);
    }
}

function deleteCategory(): void {
    requireAdmin();
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) throw new Exception('Missing category ID.');
    // Check for products using this category
    $chk = db()->prepare('SELECT COUNT(*) FROM products WHERE category_id=?');
    $chk->execute([$id]);
    if ((int)$chk->fetchColumn() > 0) {
        throw new Exception('Cannot delete: this category has products. Move or delete them first.');
    }
    $stmt = db()->prepare('DELETE FROM categories WHERE id=?');
    $stmt->execute([$id]);
    jsonResponse(['success' => true, 'message' => 'Category deleted.']);
}

// ════════════════════════════════════════════════
//  CHECKOUT (POS — transaction)
// ════════════════════════════════════════════════
function checkout(): void {
    $pdo   = db();
    $items = json_decode($_POST['items'] ?? '[]', true);
    if (!$items || !is_array($items)) throw new Exception('No items in order.');

    $discPct  = max(0, min(100, (float)($_POST['discount_pct'] ?? 0)));
    $payMeth  = $_POST['payment_method'] ?? 'cash';
    $cashRecv = (float)($_POST['cash_received'] ?? 0);
    $cardRef  = trim($_POST['card_ref']  ?? '');
    $gcashRef = trim($_POST['gcash_ref'] ?? '');

    if (!in_array($payMeth, ['cash','card','gcash'])) throw new Exception('Invalid payment method.');

    $taxRate  = (float)getSetting('tax_rate', '10') / 100;
    $subtotal = 0;
    $lineItems = [];

    // Begin DB transaction for atomicity (stock deduction + txn insert together)
    $pdo->beginTransaction();
    try {
        foreach ($items as $item) {
            $pid = (int)($item['id'] ?? 0);
            $qty = (int)($item['qty'] ?? 0);
            if ($pid <= 0 || $qty <= 0) throw new Exception('Invalid item data in order.');

            // Lock the row to prevent race conditions on stock
            $prod = $pdo->prepare('SELECT * FROM products WHERE id=? AND is_active=1 FOR UPDATE');
            $prod->execute([$pid]);
            $p = $prod->fetch();
            if (!$p) throw new Exception("Product ID $pid not found or inactive.");
            if ($p['stock'] < $qty) {
                throw new Exception("Insufficient stock for \"{$p['name']}\" (available: {$p['stock']}, requested: $qty).");
            }

            $lineTotal  = round((float)$p['price'] * $qty, 2);
            $subtotal  += $lineTotal;
            $lineItems[] = [
                'product_id'   => $pid,
                'product_name' => $p['name'],
                'product_icon' => $p['icon'],
                'unit_price'   => (float)$p['price'],
                'quantity'     => $qty,
                'line_total'   => $lineTotal,
            ];
        }

        $taxAmt      = round($subtotal * $taxRate, 2);
        $discAmt     = round($subtotal * ($discPct / 100), 2);
        $totalAmount = round($subtotal + $taxAmt - $discAmt, 2);
        $changeAmt   = $payMeth === 'cash' ? max(0, round($cashRecv - $totalAmount, 2)) : 0;

        if ($payMeth === 'cash' && $cashRecv < $totalAmount) {
            throw new Exception('Cash received ($' . number_format($cashRecv, 2) . ') is less than the total ($' . number_format($totalAmount, 2) . ').');
        }

        $uid  = currentUser()['id'];
        $code = nextTxnCode();

        // Insert transaction header
        $ins = $pdo->prepare('
            INSERT INTO transactions
              (txn_code,cashier_id,subtotal,tax_amount,discount_pct,discount_amount,
               total_amount,payment_method,cash_received,change_amount,card_ref,gcash_ref)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
        ');
        $ins->execute([$code,$uid,$subtotal,$taxAmt,$discPct,$discAmt,$totalAmount,$payMeth,$cashRecv,$changeAmt,$cardRef,$gcashRef]);
        $txnId = (int)$pdo->lastInsertId();

        // Insert line items and deduct stock
        $iStmt = $pdo->prepare('INSERT INTO transaction_items (transaction_id,product_id,product_name,product_icon,unit_price,quantity,line_total) VALUES (?,?,?,?,?,?,?)');
        $sStmt = $pdo->prepare('UPDATE products SET stock=stock-?,updated_at=NOW() WHERE id=?');
        foreach ($lineItems as $li) {
            $iStmt->execute([$txnId,$li['product_id'],$li['product_name'],$li['product_icon'],$li['unit_price'],$li['quantity'],$li['line_total']]);
            $sStmt->execute([$li['quantity'],$li['product_id']]);
        }

        $pdo->commit();

        jsonResponse([
            'success'        => true,
            'txn_code'       => $code,
            'txn_id'         => $txnId,
            'subtotal'       => $subtotal,
            'tax_amount'     => $taxAmt,
            'discount_pct'   => $discPct,
            'discount_amt'   => $discAmt,
            'total_amount'   => $totalAmount,
            'change_amount'  => $changeAmt,
            'payment_method' => $payMeth,
            'cash_received'  => $cashRecv,
            'cashier'        => currentUser()['name'],
            'items'          => $lineItems,
            'message'        => 'Payment successful!',
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function getTxn(): void {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) throw new Exception('Missing transaction ID.');
    $pdo = db();
    $txn = $pdo->prepare("SELECT t.*, u.name as cashier_name FROM transactions t JOIN users u ON t.cashier_id=u.id WHERE t.id=?");
    $txn->execute([$id]);
    $t = $txn->fetch();
    if (!$t) throw new Exception('Transaction not found.');
    $items = $pdo->prepare('SELECT * FROM transaction_items WHERE transaction_id=? ORDER BY id');
    $items->execute([$id]);
    $t['items'] = $items->fetchAll();
    jsonResponse(['success' => true, 'data' => $t]);
}

function getTxnHistory(): void {
    $pdo    = db();
    $limit  = min(100, max(1, (int)($_GET['limit'] ?? 50)));
    $offset = max(0, (int)($_GET['offset'] ?? 0));
    $uid    = (int)(currentUser()['id']);
    $role   = currentUser()['role'];

    // Admins see all; cashiers see only their own
    if (in_array($role, ['admin','manager'])) {
        $rows = $pdo->prepare("
            SELECT t.*, u.name as cashier_name,
                   (SELECT SUM(quantity) FROM transaction_items WHERE transaction_id=t.id) as item_count
            FROM transactions t JOIN users u ON t.cashier_id=u.id
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $rows->execute([$limit, $offset]);
    } else {
        $rows = $pdo->prepare("
            SELECT t.*, u.name as cashier_name,
                   (SELECT SUM(quantity) FROM transaction_items WHERE transaction_id=t.id) as item_count
            FROM transactions t JOIN users u ON t.cashier_id=u.id
            WHERE t.cashier_id=?
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $rows->execute([$uid, $limit, $offset]);
    }
    jsonResponse(['success' => true, 'data' => $rows->fetchAll()]);
}

// ════════════════════════════════════════════════
//  USER ACCOUNTS
// ════════════════════════════════════════════════
function saveUserAction(): void {
    requireAdmin();
    $pdo      = db();
    $id       = (int)($_POST['id'] ?? 0);
    $name     = trim($_POST['name'] ?? '');
    $username = strtolower(trim($_POST['username'] ?? ''));
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $phone    = trim($_POST['phone'] ?? '');
    $role     = $_POST['role'] ?? 'cashier';
    $status   = $_POST['status'] ?? 'active';
    $pw       = $_POST['password'] ?? '';

    if (!$name || !$username || !$email) throw new Exception('Name, username, and email are required.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))        throw new Exception('Invalid email address.');
    if (!preg_match('/^[a-z0-9_]{3,30}$/', $username))    throw new Exception('Username: 3–30 chars, letters/numbers/underscores.');
    if (!in_array($role, ['admin','manager','cashier']))   throw new Exception('Invalid role.');
    if (!in_array($status, ['active','inactive']))         throw new Exception('Invalid status.');

    if ($id) {
        $chk = $pdo->prepare('SELECT id FROM users WHERE (username=? OR email=?) AND id!=?');
        $chk->execute([$username, $email, $id]);
        if ($chk->fetch()) throw new Exception('Username or email already in use by another account.');

        if ($pw) {
            if (strlen($pw) < 8) throw new Exception('Password must be at least 8 characters.');
            $hash = password_hash($pw, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare('UPDATE users SET name=?,username=?,email=?,phone=?,role=?,status=?,password=?,updated_at=NOW() WHERE id=?');
            $stmt->execute([$name,$username,$email,$phone,$role,$status,$hash,$id]);
        } else {
            $stmt = $pdo->prepare('UPDATE users SET name=?,username=?,email=?,phone=?,role=?,status=?,updated_at=NOW() WHERE id=?');
            $stmt->execute([$name,$username,$email,$phone,$role,$status,$id]);
        }
        jsonResponse(['success' => true, 'message' => "\"$name\" updated."]);
    } else {
        if (!$pw || strlen($pw) < 8) throw new Exception('Password required and must be at least 8 characters.');
        $chk = $pdo->prepare('SELECT id FROM users WHERE username=? OR email=?');
        $chk->execute([$username, $email]);
        if ($chk->fetch()) throw new Exception('Username or email already in use.');
        $hash = password_hash($pw, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('INSERT INTO users (name,username,email,phone,role,status,password) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$name,$username,$email,$phone,$role,$status,$hash]);
        jsonResponse(['success' => true, 'message' => "\"$name\" added!", 'id' => $pdo->lastInsertId()]);
    }
}

function deleteUser(): void {
    requireAdmin();
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) throw new Exception('Missing user ID.');
    if ($id === (int)currentUser()['id']) throw new Exception('You cannot delete your own account.');
    // Keep user if they have transactions; just deactivate
    $chk = db()->prepare('SELECT COUNT(*) FROM transactions WHERE cashier_id=?');
    $chk->execute([$id]);
    if ((int)$chk->fetchColumn() > 0) {
        $stmt = db()->prepare("UPDATE users SET status='inactive', updated_at=NOW() WHERE id=?");
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'User deactivated (has transaction history).']);
    } else {
        $stmt = db()->prepare('DELETE FROM users WHERE id=?');
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'message' => 'User deleted.']);
    }
}

function toggleUserStatus(): void {
    requireAdmin();
    $id     = (int)($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if (!$id || !in_array($status, ['active','inactive'])) throw new Exception('Invalid request.');
    if ($id === (int)currentUser()['id']) throw new Exception('You cannot change your own status.');
    $stmt = db()->prepare('UPDATE users SET status=?,updated_at=NOW() WHERE id=?');
    $stmt->execute([$status, $id]);
    jsonResponse(['success' => true, 'message' => 'Status updated.']);
}

function resetPassword(): void {
    requireAdmin();
    $id = (int)($_POST['id'] ?? 0);
    $pw = $_POST['password'] ?? '';
    if (!$id) throw new Exception('Missing user ID.');
    if (strlen($pw) < 8) throw new Exception('Password must be at least 8 characters.');
    $hash = password_hash($pw, PASSWORD_BCRYPT);
    $stmt = db()->prepare('UPDATE users SET password=?,reset_token=NULL,reset_exp=NULL,updated_at=NOW() WHERE id=?');
    $stmt->execute([$hash, $id]);
    jsonResponse(['success' => true, 'message' => 'Password reset successfully.']);
}

/** Profile update — any logged-in user can update their own profile */
function updateProfile(): void {
    $pdo      = db();
    $uid      = (int)currentUser()['id'];
    $name     = trim($_POST['name'] ?? '');
    $username = strtolower(trim($_POST['username'] ?? ''));
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $phone    = trim($_POST['phone'] ?? '');
    $pw       = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm']  ?? '';

    if (!$name || !$username || !$email) throw new Exception('Name, username and email are required.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))     throw new Exception('Invalid email address.');
    if (!preg_match('/^[a-z0-9_]{3,30}$/', $username)) throw new Exception('Username: 3–30 chars, letters/numbers/underscores.');

    // Check uniqueness (exclude self)
    $chk = $pdo->prepare('SELECT id FROM users WHERE (username=? OR email=?) AND id!=?');
    $chk->execute([$username, $email, $uid]);
    if ($chk->fetch()) throw new Exception('Username or email already in use by another account.');

    if ($pw) {
        if (strlen($pw) < 8)  throw new Exception('Password must be at least 8 characters.');
        if ($pw !== $confirm) throw new Exception('Passwords do not match.');
        $hash = password_hash($pw, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('UPDATE users SET name=?,username=?,email=?,phone=?,password=?,updated_at=NOW() WHERE id=?');
        $stmt->execute([$name,$username,$email,$phone,$hash,$uid]);
    } else {
        $stmt = $pdo->prepare('UPDATE users SET name=?,username=?,email=?,phone=?,updated_at=NOW() WHERE id=?');
        $stmt->execute([$name,$username,$email,$phone,$uid]);
    }

    // Update session so the topbar reflects the new name immediately
    $_SESSION['user_name']  = $name;
    $_SESSION['user_email'] = $email;

    jsonResponse(['success' => true, 'message' => 'Profile updated.', 'name' => $name]);
}

// ════════════════════════════════════════════════
//  SETTINGS
// ════════════════════════════════════════════════
function saveSettings(): void {
    requireAdmin();
    $pdo  = db();
    $allowed = ['cafe_name','cafe_address','cafe_phone','tax_rate','currency','low_stock_threshold'];
    $stmt = $pdo->prepare("INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
    foreach ($allowed as $k) {
        if (isset($_POST[$k])) $stmt->execute([$k, trim($_POST[$k])]);
    }
    jsonResponse(['success' => true, 'message' => 'Settings saved.']);
}

function clearTxns(): void {
    requireAdmin();
    $pdo = db();
    $pdo->exec('DELETE FROM transaction_items');
    $pdo->exec('DELETE FROM transactions');
    jsonResponse(['success' => true, 'message' => 'All transactions cleared.']);
}